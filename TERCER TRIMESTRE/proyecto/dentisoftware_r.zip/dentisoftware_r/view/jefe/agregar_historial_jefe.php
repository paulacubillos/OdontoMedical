<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Historial Clínico</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Agregar Historial Clínico</h2>
        <form action="agregar_historial_jefe.php" method="POST">
            <div class="mb-3">
                <label for="fecha_actualizacion" class="form-label">Fecha de Actualización</label>
                <input type="text" class="form-control" id="fecha_actualizacion" name="fecha_actualizacion" required>
            </div>
            <div class="mb-3">
                <label for="descripcion_tratamiento" class="form-label">Descripción del Tratamiento</label>
                <textarea class="form-control" id="descripcion_tratamiento" name="descripcion_tratamiento" required></textarea>
            </div>
            <div class="mb-3">
                <label for="fecha_tratamiento" class="form-label">Fecha del Tratamiento</label>
                <input type="date" class="form-control" id="fecha_tratamiento" name="fecha_tratamiento" required>
            </div>
            <div class="mb-3">
                <label for="id_ortodoncista" class="form-label">ID Ortodoncista</label>
                <input type="number" class="form-control" id="id_ortodoncista" name="id_ortodoncista" required>
            </div>
            <div class="mb-3">
                <label for="id_doctor" class="form-label">ID Doctor</label>
                <input type="number" class="form-control" id="id_doctor" name="id_doctor" required>
            </div>
            <button type="submit" class="btn btn-primary">Agregar Historial</button>
        </form>
    </div>
</body>
</html>
