<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>INCIO</title>
    <link rel="stylesheet" href="../../assets/css/inicio_odo.css">
</head>
<body>
  <header>
  <nav class="navbar bg-body-tertiary">
    <div class="container-fluid">
      <a class="navbar-brand" href="inicio_odo.php">
        <img src="../../assets/img/person.svg" alt="Logo" width="30" height="24" class="d-inline-block align-text-top">
        ODONTO MEDICAL
      </a>
      <a class="nav-link active" aria-current="page" href="inicio_odo.php">Inicio</a>
      <a class="nav-link active" aria-current="page" href="servicios_odo.php">Servicios</a>
      <a class="nav-link active" aria-current="page" href="nosotros_odo.php">Nosotros</a>
      <a class="nav-link active" aria-current="page" href="contacto_odo.php">Contacto</a>
      <a class="nav-link text-danger" href="../../controller/cerrar_sesion.php">Cerrar Sesión</a>
      <a class="btn btn-primary" aria-current="page" href="agendar_cita_odo.php">Agendar cita</a>
    </div>
  </nav>
</header>
<div class="container">
  <img src="../../assets/img/cont-1.jpeg" alt="Dentist Image" class="image_1">
    <div class="text-block">
        <h1>DRA. YAMILE GUZMAN</h1>
        <p>Especialista en Periodoncia e Implantología</p>
        <p>Más de 12 Años de experiencia en el área</p>
        <p>OdontoMedical, Innovación y cuidado para cada sonrisa</p>
    </div>
    <a href="servicios_odo.php" class="button">CONSULTA DE VALORACION</a>
</div>
<div class="row">
  <div class="col-sm-6 mb-3 mb-sm-0">
    <div class="card">
      <div class="card-body">
        <img src="#" alt="Dentist Image_2" class="image_2">
        <p class="card-text">Manejamos estética y
          funcionalidad en tus tratamientos Por eso, en OdontoMedical encontrarás múltiples tratamientos con beneficios para tu salud dental y a precios moderados. 
          Gracias a la calidad y excelencia de nuestros proveedores y a la idoneidad de nuestros especialistas podemos brindarte un servicio ético y de calidad para cumplir con tus expectativas.</p>
        <a href="servicios_odo.php" class="btn btn-primary">Conoce los tratamientos de ortodoncia que tenemos para ti</a>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <img src="" alt="Dentist Image_3" class="image">
        <p class="card-text">Tu sonrisa es nuestro compromiso Por eso, en OdontoMedical encontrarás múltiples tratamientos con beneficios para tu salud dental y a precios moderados. 
          Gracias a la calidad y excelencia de nuestros proveedores y a la idoneidad de nuestros especialistas podemos brindarte un servicio ético y de calidad para cumplir con tus expectativas.</p>
        <a href="nosotros_odo.php" class="btn btn-primary">Acerca de nosotros</a>
      </div>
    </div>
  </div>
</div>
<section class="contact-section">
  <h2>Contacto</h2>
  <div class="contact-container">
      <div class="contact-box">
          <img src="../../assets/img/whatsapp.svg" alt="WhatsApp" width="50">
          <p>+57 320 0225854</p>
          <p>(601) 7452 155</p>
      </div>
      <div class="contact-box">
          <img src="../../assets/img/email.svg" alt="Email" width="50">
          <p>@OdontoMedical_Clinica</p>
          <p>odontomedical@gmail.com</p>
      </div>
  </div>
  <div class="map-box">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3976.580152184535!2d-74.11929382650655!3d4.668691441937296!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f9b78be3bf4fd%3A0x65b5e6a92f443720!2zQ3JhLiA3NSAjMjVjMjQsIEZvbnRpYsOzbiwgQm9nb3TDoQ!5e0!3m2!1ses-419!2sco!4v1724861656866!5m2!1ses-419!2sco" 
    width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
  </div>
</section>
<footer>
<div class="footer-container">
    <div class="footer-section">
        <h4>Servicios :</h4>
        <ul>
          <li><a href="#">Blanqueamiento dental</a></li>
          <li><a href="#">Ortodoncia</a></li>
          <li><a href="#">Rehabilitación Oral</a></li>
          <li><a href="#">Implantes dentales</a></li>
        </ul>
    </div>
    <div class="footer-section">
        <h4>Sobre OdontoMedical:</h4>
        <ul>
            <li><a href="nosotros_odo.php">Acerca de nosotros</a></li>
        </ul>
    </div>
    <div class="footer-section">
        <h4>Síguenos en nuestras redes</h4>
        <div class="social-media">
        <img src="../../assets/img/email.svg" alt="Email" width="50">
        <img src="../../assets/img/whatsapp.svg" alt="WhatsApp" width="50">
        </div>
        <p>Dirección: Calle 70 sur #78-25</p>
        <p>Teléfono: 7566656</p>
        <p>Correo: odontomedical@gmail.com</p>
    </div>
</div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>