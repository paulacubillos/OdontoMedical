<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Nosotros</title>
    <link rel="stylesheet" href="../../assets/css/nosotros_odo.css">
</head>
<body>
<header>
  <nav class="navbar bg-body-tertiary">
    <div class="container-fluid">
      <a class="navbar-brand" href="inicio_odo.php">
        <img src="../../assets/img/person.svg" alt="Logo" width="30" height="24" class="d-inline-block align-text-top">
        ODONTO MEDICAL
      </a>
      <a class="nav-link active" aria-current="page" href="inicio_odo.php">Inicio</a>
      <a class="nav-link active" aria-current="page" href="servicios_odo.php">Servicios</a>
      <a class="nav-link active" aria-current="page" href="nosotros_odo.php">Nosotros</a>
      <a class="nav-link active" aria-current="page" href="contacto_odo.php">Contacto</a>
      <a class="nav-link text-danger" href="../../controller/cerrar_sesion.php">Cerrar Sesión</a>
      <a class="btn btn-primary" aria-current="page" href="agendar_cita_odo.php">Agendar cita</a>
    </div>
  </nav>
</header>
    <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="../../assets/img/carrusel_1.png" class="d-block w-100" alt="...">
        </div>
        <div class="carousel-item">
          <img src="../../assets/img/carrusel_2.png" class="d-block w-100" alt="...">
        </div>
        <div class="carousel-item">
          <img src="../../assets/img/carrusel_3.png" class="d-block w-100" alt="...">
        </div>
      </div>
    </div>
        <div class="container">
        <div class="row">
          <div class="col-sm-6 mb-3 mb-sm-0">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Misión</h5>
                <p class="card-text">En Odontomedical, nos dedicamos a ofrecer una atención odontológica integral, 
                  basada en las necesidades únicas de cada paciente y en los más recientes avances científicos.</p>
              </div>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Visión</h5>
                <p class="card-text">Ser líder en odontología, ofreciendo servicios de alta calidad y
                   atención personalizada respaldada por tecnología innovadora, 
                   buscando destacar como un centro de excelencia reconocido mundialmente por nuestro compromiso
                   con la salud bucal y el bienestar de los pacientes.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    <footer>
      <div class="footer-container">
          <div class="footer-section">
              <h4>Servicios :</h4>
              <ul>
                <li><a href="#">Blanqueamiento dental</a></li>
                <li><a href="#">Ortodoncia</a></li>
                <li><a href="#">Rehabilitación Oral</a></li>
                <li><a href="#">Implantes dentales</a></li>
              </ul>
          </div>
          <div class="footer-section">
              <h4>Sobre OdontoMedical:</h4>
              <ul>
                  <li><a href="nosotros_odo.php">Acerca de nosotros</a></li>
              </ul>
          </div>
          <div class="footer-section">
              <h4>Síguenos en nuestras redes</h4>
              <div class="social-media">
                  <a href="#"><img src="../../assets/img/whatsapp.svg" alt="WhatsApp"></a>
              </div>
              <p>Dirección: Calle 70 sur #78-25</p>
              <p>Teléfono: 7566656</p>
              <p>Correo: odontomedical@gmail.com</p>
          </div>
      </div>
  </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>   
</body>
</html>