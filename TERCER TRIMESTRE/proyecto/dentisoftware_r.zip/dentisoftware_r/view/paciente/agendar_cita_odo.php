<?php
include '../../model/db.php'; 
session_start();

if (isset($_GET['servicio_id'])) {
    $servicio_id = $_GET['servicio_id'];
    $servicio = $conexion->query("SELECT * FROM servicios WHERE id = $servicio_id")->fetch(PDO::FETCH_ASSOC);
    
    if (!$servicio) {
        die("Servicio no encontrado.");
    }
} else {
    header('Location: servicios_odo.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Agendar Cita</title>
</head>
<body>
<header>
  <nav class="navbar bg-body-tertiary">
    <div class="container-fluid">
      <a class="navbar-brand" href="inicio_odo.php">ODONTO MEDICAL</a>
      <a class="btn btn-secondary" href="servicios_odo.php">Volver</a>
      <a class="nav-link text-danger" href="../../controller/cerrar_sesion.php">Cerrar Sesión</a>
    </div>
  </nav>
</header>

<div class="container mt-5">
    <h1 class="text-center mb-4">Agendar Cita para <?= htmlspecialchars($servicio['nombre'], ENT_QUOTES) ?></h1>
    
    <form action="../../controller/agendar_cita_guardar.php" method="post">
        <div class="mb-3">
            <label for="numero_documento" class="form-label">Número de Documento</label>
            <input type="text" class="form-control" id="numero_documento" name="numero_documento" required>
        </div>
        <div class="mb-3">
            <label for="fecha" class="form-label">Fecha</label>
            <input type="date" class="form-control" id="fecha" name="fecha" required>
        </div>
        <div class="mb-3">
            <label for="hora" class="form-label">Hora</label>
            <input type="time" class="form-control" id="hora" name="hora" required>
        </div>
        <input type="hidden" name="servicio_id" value="<?= $servicio_id ?>">
        <input type="hidden" name="procedimiento" value="<?= htmlspecialchars($servicio['nombre'], ENT_QUOTES) ?>">
        <input type="hidden" name="doctora" value="Yamile">
        <input type="hidden" name="consultorio" value="1">
        <button type="submit" class="btn btn-primary">Agendar Cita</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
