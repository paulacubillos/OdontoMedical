<?php
session_start();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Confirmación de Cita</title>
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">Cita Agendada Exitosamente</h1>
    <p class="text-center">
        Cita agendada para el día <?= isset($_SESSION['fecha']) ? date('d/m/Y', strtotime($_SESSION['fecha'])) : 'Desconocida'; ?> 
        a las <?= isset($_SESSION['hora']) ? date('h:i A', strtotime($_SESSION['hora'])) : 'Desconocida'; ?> 
        en el consultorio <?= isset($_SESSION['consultorio']) ? $_SESSION['consultorio'] : 'Desconocido'; ?>.
    </p>
    <div class="text-center">
        <a href="inicio_odo.php" class="btn btn-primary">Volver al Inicio</a>
        <a href="servicios_odo.php" class="btn btn-secondary">Ver Servicios</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
