<?php
include '../../model/db.php'; 
session_start();
$servicios = $conexion->query("SELECT * FROM servicios WHERE estado = 'activo'")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../assets/css/servicios_odo.css">
    <title>Servicios</title>
</head>
<body>
<header>
  <nav class="navbar bg-body-tertiary">
    <div class="container-fluid">
      <a class="navbar-brand" href="inicio_odo.php">ODONTO MEDICAL</a>
      <a class="nav-link active" aria-current="page" href="inicio_odo.php">Inicio</a>
      <a class="nav-link active" aria-current="page" href="servicios_odo.php">Servicios</a>
      <a class="nav-link active" aria-current="page" href="nosotros_odo.php">Nosotros</a>
      <a class="nav-link active" aria-current="page" href="contacto_odo.php">Contacto</a>
      <a class="nav-link text-danger" href="../../controller/cerrar_sesion.php">Cerrar Sesión</a>
      <a class="btn btn-primary" href="agendar_cita_odo.php">Agendar cita</a>
    </div>
  </nav>
</header>
<div class="container mt-5">
    <h1 class="text-center mb-4">Servicios Disponibles</h1>
    <div class="row row-cols-1 row-cols-md-2 g-4">
        <?php foreach ($servicios as $servicio): ?>
        <div class="col">
          <div class="card h-100">
            <?php if ($servicio['imagen']): ?>
              <img src="<?= htmlspecialchars($servicio['imagen'], ENT_QUOTES) ?>" class="card-img-top" alt="<?= htmlspecialchars($servicio['nombre'], ENT_QUOTES) ?>">
            <?php endif; ?>
            <div class="card-body">
              <h5 class="card-title"><?= htmlspecialchars($servicio['nombre'], ENT_QUOTES) ?></h5>
              <p class="card-text"><?= htmlspecialchars($servicio['descripcion'], ENT_QUOTES) ?></p>
              <p class="card-text"><strong>Precio:</strong> $<?= htmlspecialchars($servicio['precio'], ENT_QUOTES) ?></p>
              <a href="agendar_cita_odo.php?servicio_id=<?= $servicio['id'] ?>" class="btn btn-primary">Agendar</a>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<footer>
    <div class="footer-container">
        <div class="footer-section">
            <h4>Servicios :</h4>
            <ul>
                <li><a href="#">Blanqueamiento dental</a></li>
                <li><a href="#">Ortodoncia</a></li>
                <li><a href="#">Rehabilitación Oral</a></li>
                <li><a href="#">Implantes dentales</a></li>
                <li><a href="#">Cirugía Molar</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h4>Sobre OdontoMedical:</h4>
            <ul>
                <li><a href="nosotros_odo.php">Acerca de nosotros</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h4>Síguenos en nuestras redes</h4>
            <div class="social-media">
                <a href="#"><img src="img/instagram.svg" alt="Instagram"></a>
                <a href="#"><img src="img/whatsapp.svg" alt="WhatsApp"></a>
            </div>
            <p>Dirección: Calle 70 sur #78-25</p>
            <p>Teléfono: 7566656</p>
            <p>Correo: odontomedical@gmail.com</p>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>   
</body>
</html>
