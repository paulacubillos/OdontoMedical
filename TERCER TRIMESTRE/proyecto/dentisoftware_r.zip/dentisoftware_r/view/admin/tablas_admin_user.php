<?php
include '../../model/db.php';
$registros_por_pagina = 10;
$busqueda = isset($_GET['busqueda']) ? $_GET['busqueda'] : '';
if ($busqueda) {
    $stmt = $conexion->prepare("SELECT COUNT(*) FROM usuario WHERE numero_documento LIKE ?");
    $stmt->execute(["%$busqueda%"]);
} else {
    $stmt = $conexion->prepare("SELECT COUNT(*) FROM usuario");
    $stmt->execute();
}
$total_registros = $stmt->fetchColumn();
$total_paginas = ceil($total_registros / $registros_por_pagina);
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$inicio = ($pagina_actual - 1) * $registros_por_pagina;
if ($busqueda) {
    $stmt = $conexion->prepare("SELECT * FROM usuario WHERE numero_documento LIKE ? LIMIT $inicio, $registros_por_pagina");
    $stmt->execute(["%$busqueda%"]);
} else {
    $stmt = $conexion->prepare("SELECT * FROM usuario LIMIT $inicio, $registros_por_pagina");
    $stmt->execute();
}

$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Usuarios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="index_crud_odo.php">Administración</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                            <a class="nav-link active" href="tablas_admin_user.php">Usuarios</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="agenda_admin.php">Agenda</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Historiales</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index_crud_servicios.php">Productos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-danger" href="../../controller/cerrar_sesion.php">Cerrar Sesión</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <div class="container mt-5">
        <h1 class="mb-4">Lista de Usuarios</h1>
        <form class="d-flex mb-4" method="GET" action="">
            <input class="form-control me-2" type="search" name="busqueda" placeholder="Buscar por Número de Documento" value="<?= $busqueda; ?>">
            <button class="btn btn-outline-success" type="submit">Buscar</button>
        </form>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Tipo Documento</th>
                    <th>Número Documento</th>
                    <th>Edad</th>
                    <th>Correo</th>
                    <th>Teléfono</th>
                    <th>Rol</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($usuarios as $usuario): ?>
                    <tr>
                        <td><?= $usuario['id']; ?></td>
                        <td><?= $usuario['nombre']; ?></td>
                        <td><?= $usuario['apellido']; ?></td>
                        <td><?= $usuario['tipo_documento']; ?></td>
                        <td><?= $usuario['numero_documento']; ?></td>
                        <td><?= $usuario['edad']; ?></td>
                        <td><?= $usuario['correo']; ?></td>
                        <td><?= $usuario['telefono']; ?></td>
                        <td><?= $usuario['rol']; ?></td>
                        <td>
                            <a href="../../controller/update_user.php?id=<?= $usuario['id']; ?>" class="btn btn-warning btn-sm">Editar</a>
                            <a href="../../controller/delete_user.php?id=<?= $usuario['id']; ?>" class="btn btn-danger btn-sm">Eliminar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <nav aria-label="Paginación">
            <ul class="pagination justify-content-center">
                <?php if ($pagina_actual > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?pagina=<?= $pagina_actual - 1; ?>&busqueda=<?= $busqueda; ?>">Anterior</a>
                    </li>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                    <li class="page-item <?= $i == $pagina_actual ? 'active' : ''; ?>">
                        <a class="page-link" href="?pagina=<?= $i; ?>&busqueda=<?= $busqueda; ?>"><?= $i; ?></a>
                    </li>
                <?php endfor; ?>
                
                <?php if ($pagina_actual < $total_paginas): ?>
                    <li class="page-item">
                        <a class="page-link" href="?pagina=<?= $pagina_actual + 1; ?>&busqueda=<?= $busqueda; ?>">Siguiente</a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</body>
</html>