<?php
include '../../model/db.php';
session_start();

$registros_por_pagina = 10;
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$inicio = ($pagina_actual > 1) ? ($pagina_actual * $registros_por_pagina) - $registros_por_pagina : 0;
$busqueda = isset($_GET['busqueda']) ? $_GET['busqueda'] : '';
$sql = "SELECT * FROM servicios WHERE nombre LIKE :busqueda LIMIT :inicio, :registros_por_pagina";
$stmt = $conexion->prepare($sql);
$stmt->bindValue(':busqueda', '%' . $busqueda . '%', PDO::PARAM_STR);
$stmt->bindValue(':inicio', (int)$inicio, PDO::PARAM_INT);
$stmt->bindValue(':registros_por_pagina', (int)$registros_por_pagina, PDO::PARAM_INT);
$stmt->execute();
$servicios = $stmt->fetchAll(PDO::FETCH_ASSOC);
$sql_total = "SELECT COUNT(*) FROM servicios WHERE nombre LIKE :busqueda";
$stmt_total = $conexion->prepare($sql_total);
$stmt_total->bindValue(':busqueda', '%' . $busqueda . '%', PDO::PARAM_STR);
$stmt_total->execute();
$total_servicios = $stmt_total->fetchColumn();
$total_paginas = ceil($total_servicios / $registros_por_pagina);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Servicios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="index_crud_odo.php">Administración</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active" href="tablas_admin_user.php">Usuarios</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="agenda_admin.php">Agenda</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Historiales</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index_crud_servicios.php">Productos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-danger" href="../../controller/cerrar_sesion.php">Cerrar Sesión</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <div class="container mt-5">
        <h1 class="text-center">Lista de Servicios</h1>
        <form class="mb-3" method="GET" action="index_crud_servicios.php">
            <input type="text" name="busqueda" class="form-control" placeholder="Buscar por nombre" value="<?= htmlspecialchars($busqueda, ENT_QUOTES) ?>">
        </form>
        <a href="../../controller/crear_servicio.php" class="btn btn-success mb-3">Crear Servicio</a>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Precio</th>
                    <th>Estado</th>
                    <th>Imagen</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($servicios as $servicio): ?>
                <tr>
                    <td><?= $servicio['id'] ?></td>
                    <td><?= htmlspecialchars($servicio['nombre'], ENT_QUOTES) ?></td>
                    <td><?= htmlspecialchars($servicio['descripcion'], ENT_QUOTES) ?></td>
                    <td><?= $servicio['precio'] ?></td>
                    <td><?= $servicio['estado'] ?></td>
                    <td><?= $servicio['imagen'] ? '<img src="../../assets/img/' . $servicio['imagen'] . '" width="100" />' : 'No tiene imagen' ?></td>
                    <td>
                        <a href="../../controller/update_servicio.php?id=<?= $servicio['id'] ?>" class="btn btn-primary btn-sm">Editar</a>
                        <a href="../../controller/delete_servicio.php?id=<?= $servicio['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de que deseas eliminar este servicio?')">Eliminar</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <nav>
            <ul class="pagination justify-content-center">
                <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                <li class="page-item <?= ($pagina_actual === $i) ? 'active' : '' ?>">
                    <a class="page-link" href="index_crud_servicios.php?pagina=<?= $i ?>&busqueda=<?= htmlspecialchars($busqueda, ENT_QUOTES) ?>">
                        <?= $i ?>
                    </a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


