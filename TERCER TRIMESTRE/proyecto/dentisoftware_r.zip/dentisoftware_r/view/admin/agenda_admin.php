<?php
include '../../model/db.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Administración</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="index_crud_odo.php">Administración</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active" href="tablas_admin_user.php">Usuarios</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="agenda_admin.php">Agenda</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Historiales</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index_crud_servicios.php">Productos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-danger" href="../../controller/cerrar_sesion.php">Cerrar Sesión</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main class="container mt-5">
        <h1>Bienvenido ADMIN</h1>
        <h2>Citas Agendadas</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Nombre Paciente</th>
                    <th>Hora</th>
                    <th>Procedimiento</th>
                    <th>Consultorio</th>
                    <th>Fecha</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php
$query = $conexion->query("SELECT * FROM citas ORDER BY fecha, hora");
while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
    $procedimiento = !empty($row['procedimiento']) ? $row['procedimiento'] : 'Desconocido';
    
    echo "<tr>
        <td>{$row['nombre_paciente']}</td>
        <td>{$row['hora']}</td>
        <td>{$procedimiento}</td>
        <td>{$row['consultorio']}</td>
        <td>{$row['fecha']}</td>
        <td>
            <a href='../../controller/cancelar_cita.php?id={$row['Id_Cita']}' class='btn btn-danger' onclick='return confirm(\"¿Estás seguro de que deseas cancelar esta cita?\");'>
                Cancelar
            </a>
        </td>
    </tr>";
}
?>

            </tbody>
        </table>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
