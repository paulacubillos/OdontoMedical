<?php
session_start();

if (!isset($_SESSION['correo']) || !isset($_SESSION['rol'])) {
    header("Location: ../iniciar_sesion.php");
    exit;
}

$rol = $_SESSION['rol']; 


switch ($rol) {
    case 1: // ADMIN
        header("Location: ../view/admin/index_crud_odo.php");
        break;
    case 2: // JEFE
        header("Location: ../view/jefe/jefe_dashboard.php");
        break;
    case 3: // RECEPCIONISTA
        header("Location: ../view/recepcionista/recepcionista_dashboard.php");
        break;
    case 4: // PACIENTE
        header("Location: ../view/paciente/inicio_odo.php");
        break;
    default:
        // manda al inicio de sesion
        header("Location: ../iniciar_sesion.php");
        break;
}

exit;
?>
 

