-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 30-09-2024 a las 20:52:55
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `dentisoftware`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `citas`
--

CREATE TABLE `citas` (
  `Id_Cita` int(11) NOT NULL,
  `nombre_paciente` varchar(100) NOT NULL,
  `hora` time NOT NULL,
  `procedimiento` enum('rehabilitación oral','implantes dentales','blanqueamiento dental','ortodoncia') NOT NULL,
  `consultorio` int(11) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `citas`
--

INSERT INTO `citas` (`Id_Cita`, `nombre_paciente`, `hora`, `procedimiento`, `consultorio`, `fecha`) VALUES
(3, 'Luis', '17:40:00', 'blanqueamiento dental', 1, '2024-10-24');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `consultorio`
--

CREATE TABLE `consultorio` (
  `Id_Consultorio` int(11) NOT NULL COMMENT 'En este espacio va a estar el identificador del consultorio al que se le va a poder asignar una cita ',
  `Nombre_Consultorio` varchar(45) NOT NULL COMMENT 'En este campo va a estar el nombre del consultorio '
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `consultorio`
--

INSERT INTO `consultorio` (`Id_Consultorio`, `Nombre_Consultorio`) VALUES
(1, 'Consultorio 1'),
(2, 'Consultorio 2');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial_clinico`
--

CREATE TABLE `historial_clinico` (
  `Id_Historial` int(11) NOT NULL COMMENT 'Identificador  del historial clinico',
  `Fecha_Actualizacion` varchar(45) NOT NULL COMMENT 'Fecha del actualizacion/modificacion del historial clinico',
  `Descripcion_tratamiento` varchar(45) NOT NULL COMMENT 'En este campo de la tabla va a estar la descripcion que escribira el doctor/ortodoncista sobre que se realizo en el tratamiento,',
  `Fecha_tratamiento` date NOT NULL COMMENT 'En este campo va a estar la fecha en el que el tratamiento fue realizado.',
  `ORTODONCISTA_Id_ortodoncista` int(11) NOT NULL,
  `DOCTOR_Id_Doctor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `historial_clinico`
--

INSERT INTO `historial_clinico` (`Id_Historial`, `Fecha_Actualizacion`, `Descripcion_tratamiento`, `Fecha_tratamiento`, `ORTODONCISTA_Id_ortodoncista`, `DOCTOR_Id_Doctor`) VALUES
(1, '2024-09-01', 'Limpieza dental', '2024-08-28', 0, 201),
(2, '2024-09-05', 'Ortodoncia inicial', '2024-09-01', 0, 202),
(3, '2024-09-10', 'Extracción de muela', '2024-09-08', 0, 203),
(4, '2024-09-15', 'Colocación de brackets', '2024-09-12', 0, 201),
(5, '2024-09-18', 'Control de caries', '2024-09-15', 0, 204),
(6, '2024-09-20', 'Endodoncia', '2024-09-17', 0, 202),
(7, '2024-09-22', 'Implante dental', '2024-09-20', 0, 205),
(8, '2024-09-25', 'Revisión ortodóntica', '2024-09-23', 0, 201),
(9, '2024-09-28', 'Tratamiento de conducto', '2024-09-26', 0, 203),
(10, '2024-09-30', 'Limpieza y blanqueamiento', '2024-09-29', 0, 204);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permisos`
--

CREATE TABLE `permisos` (
  `id` int(11) NOT NULL,
  `rol` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `permisos`
--

INSERT INTO `permisos` (`id`, `rol`) VALUES
(1, 'administrador'),
(2, 'jefe'),
(3, 'recepcionista'),
(4, 'paciente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicios`
--

CREATE TABLE `servicios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `estado` varchar(50) NOT NULL,
  `imagen` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `servicios`
--

INSERT INTO `servicios` (`id`, `nombre`, `descripcion`, `precio`, `estado`, `imagen`) VALUES
(1, 'Rehabilitación Oral..', 'Tratamiento integral que busca restaurar la función y estética dental mediante coronas, puentes y prótesis.', 0.00, 'activo', NULL),
(2, 'Implantes Dentales', 'Procedimiento quirúrgico para reemplazar dientes perdidos, utilizando tornillos de titanio que se integran con el hueso.', 0.00, 'activo', NULL),
(3, 'Ortodoncia', 'Tratamiento que corrige la posición de los dientes y mandíbulas, utilizando aparatos como brackets y alineadores.', 0.00, 'activo', NULL),
(4, 'Blanqueamiento Dental', 'Proceso estético que utiliza productos específicos para eliminar manchas y aclarar el color de los dientes.', 0.00, 'activo', NULL),
(5, 'Cirugía Molar', 'Intervención quirúrgica para la extracción de muelas del juicio o molares impactados, cuando causan dolor o complicaciones.', 0.00, 'activo', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `tipo_documento` enum('T.I','C.C','Pasaporte') NOT NULL,
  `numero_documento` varchar(50) NOT NULL,
  `edad` int(3) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `rol` int(11) NOT NULL DEFAULT 4
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `nombre`, `apellido`, `tipo_documento`, `numero_documento`, `edad`, `correo`, `password`, `telefono`, `rol`) VALUES
(2, 'María', 'García', 'T.I', '234511111', 32, 'maria.garcia@hotmail.com', '400797fe6057195b0972f8e972838ffeb78ac07ddef6b952575353c0a70bea57', '3012345678', 4),
(4, 'Ana', 'López', 'C.C', '45678901', 22, 'ana.lopez@hotmail.com', 'c6f95731889f8184ef6452b80c167543f3aad4341beecc3d0ee58253e2f4b1bf', '3034567890', 4),
(5, 'Luis', 'Martínez', 'T.I', '56789012', 35, 'luis.martinez@gmail.com', '18cb025eb5a732d135403f9c07dca292e62688d32d11e3bd19b45cac14cfa77b', '3045678901', 4),
(6, 'Sofía', 'Hernández', 'Pasaporte', '67890123', 26, 'sofia.hernandez@hotmail.com', 'ca8d206cf82c6f27cc5a7d413dcf1ef186019b48d98aafd09ae534277553bc51', '3056789012', 4),
(7, 'Javier', 'González', 'C.C', '78901234', 29, 'javier.gonzalez@gmail.com', '78606b442d01bb8624de0ab8962b0d431252fabd350ca782ef0c89bd8ff86cb0', '3067890123', 4),
(8, 'Valentina', 'Ramírez', 'T.I', '89012345', 24, 'valentina.ramirez@hotmail.com', 'fba4557e630c2928a6ff949d3af8a6d7cc28392c24010f126c7ce87edefa4da9', '3078901234', 4),
(9, 'Andrés', 'Díaz', 'Pasaporte', '90123456', 32, 'andres.diaz@gmail.com', '8f413c8013eadeabb14bcf72d1d32e979c6495627d83673f2d54694d34322c7c', '3089012345', 4),
(10, 'Laura', 'Cruz', 'C.C', '01234567', 27, 'laura.cruz@hotmail.com', '9bd5535a79986fa17683dc841b45857442c133ec7a5ff9fa91e8dedc6676737c', '3090123456', 4),
(11, 'Diego', 'Flores', 'T.I', '12345678', 31, 'diego.flores@gmail.com', '6c3be839d87682c8020691fefb3eff62c00ea4f3e3900f38d745786319437e98', '3101234567', 1),
(12, 'Camila', 'Morales', 'Pasaporte', '23456789', 23, 'camila.morales@hotmail.com', 'f36d7172c4d8f5a74a7a684c73387fdf8a90e2e1947978dc9e18eb5f3ccdb502', '3112345678', 4),
(13, 'Felipe', 'Vargas', 'C.C', '34567890', 30, 'felipe.vargas@gmail.com', '5dfb2834503dbf3cc72bf97ecd4af655d3782e1ca24ea38e41b7ff865c12fcee', '3123456789', 4),
(14, 'Gabriela', 'Castillo', 'T.I', '45678901', 28, 'gabriela.castillo@hotmail.com', '9851b973572e99f38d1a2aa4a5218580eea965231ebc8b06f5402eb525b32b10', '3134567890', 4),
(15, 'Santiago', 'Jiménez', 'Pasaporte', '56789012', 26, 'santiago.jimenez@gmail.com', '91d949f1cb109040f8c33b1f6e2adadfec4e6fa14dc75e163a6c847282e2b662', '3145678901', 4),
(16, 'Natalia', 'Ríos', 'C.C', '67890123', 25, 'natalia.rios@hotmail.com', 'b6789f23a1e397a1b2c765bb8b46f25af85be11e44712a7c6a95df78d6d5d957', '3156789012', 4),
(17, 'Mateo', 'Salazar', 'T.I', '78901234', 34, 'mateo.salazar@gmail.com', 'f909dc096d69ad2dc49ca9973b99aee33c485a049771e83991ef93ccaa46e4fd', '3167890123', 4),
(18, 'Isabella', 'Pineda', 'Pasaporte', '89012345', 22, 'isabella.pineda@hotmail.com', '397af6d18d0c5b33179719c432b11aebd26cb759192df1d9e9af2dd25702757e', '3178901234', 4),
(19, 'Sebastián', 'Alvarez', 'C.C', '90123456', 33, 'sebastian.alvarez@gmail.com', '7d28bfdc8a16dd37617de43430474b9a4be1cf246b68c0893af6acb2879276e0', '3189012345', 4),
(20, 'Valeria', 'Mena', 'T.I', '01234567', 29, 'valeria.mena@hotmail.com', '932d33e54b8c7012a6056cfa6cd5093aad814eb44965e41785c00145b706cfe4', '3190123456', 4),
(21, 'Daniel', 'Córdoba', 'Pasaporte', '12345678', 31, 'daniel.cordoba@gmail.com', '16e81421b74c81bdaab0e2e94bcb4a4583b609a1f6bbb496b0b94e12efcf2ef3', '3201234567', 4),
(22, 'Lucía', 'Sánchez', 'C.C', '23456789', 24, 'lucia.sanchez@hotmail.com', '2eb9996818f133cc1fee7ef3a16c4ac626475380b5cf89e0ea8a0e36fa3784fd', '3212345678', 4),
(23, 'Alejandro', 'Ceballos', 'T.I', '34567890', 30, 'alejandro.ceballos@gmail.com', 'e7cdf679d70f5c0efacbda2329baa1603a3b070591d4ffa6796acbb4770086c4', '3223456789', 3),
(24, 'Mariana', 'Quintero', 'Pasaporte', '45678901', 28, 'mariana.quintero@hotmail.com', '8a92eec7fc7c6e6205df348b5476e3facc6828ab888c6c8f38c7c8eb35a9c3bd', '3234567890', 4),
(25, 'Hugo', 'Sierra', 'C.C', '56789012', 35, 'hugo.sierra@gmail.com', '1a53d6f13980c85d9ce302c2aeac55f36088958910ccec36e4abc66cba0213ff', '3245678901', 4),
(52, 'carlota', 'adarme', 'T.I', '225866996', 38, 'cargahq@gmail.com', '$2y$10$lrMcfRS6ZkzAfJKh.taQ.e6tXCS3.Cpor.hbuWtLDkx9NauD7W7x6', '123456', 4),
(54, 'Carlos', 'Alvarez', 'T.I', '1025533382', 17, 'admin@gmail.com', '$2y$10$ZPV4Dpff1JygzQKgiWYfUeMnH3fezKdiRiom5pnVbpMskgJbbRtsG', '3229496405', 1),
(55, 'Carol', 'Vargas', 'T.I', '19368362983', 17, 'jefe@gmail.com', '$2y$10$lwVHPRygrX3KpxYQqACFLOj0QNm8Rj3qxd12eLChhq7lGzYyQGXHK', '3229873643', 2),
(56, 'Leo', 'Rivas', 'T.I', '53627721', 17, 'leo@gmail.com', '$2y$10$5c/aBK7mpN82zpMI5CqwXu2KdRRbUrO5cbDjzfso8eQrmjRae/a9u', '328883763', 4),
(57, 'manu', 'galindo', 'T.I', '234567800', 17, 'manu@gmail.com', '$2y$10$/n5tRM9gpRfnuH8bkCu7W.vcNUPPZtjriIAIXkGkFrB3wYpP/uMcm', '3226736546', 4),
(58, 'paula', 'cubillos', 'C.C', '256366', 18, 'recep@gmail.com', '$2y$10$/gAawnIKhsD6nHsHbEEtC.WHVKYNuRd3R0.fqckJPJNF40/YZOBAK', '322887663', 3),
(59, 'lukas', 'alvarez', 'T.I', '18287634', 16, 'lukas@gmail.com', '$2y$10$kpZmRf8C4M1JFkPCA0TnGuFxxB6N8biAX/frjpxoPr5wQ63iZDaEC', '322878345', 4);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `citas`
--
ALTER TABLE `citas`
  ADD PRIMARY KEY (`Id_Cita`);

--
-- Indices de la tabla `consultorio`
--
ALTER TABLE `consultorio`
  ADD PRIMARY KEY (`Id_Consultorio`);

--
-- Indices de la tabla `historial_clinico`
--
ALTER TABLE `historial_clinico`
  ADD PRIMARY KEY (`Id_Historial`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `citas`
--
ALTER TABLE `citas`
  MODIFY `Id_Cita` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
