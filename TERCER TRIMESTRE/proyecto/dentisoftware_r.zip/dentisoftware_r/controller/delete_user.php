<?php
include '../model/db.php';

$id = $_GET['id'];

if (isset($_POST['confirm_delete'])) {
    $stmt = $conexion->prepare("DELETE FROM usuario WHERE id = ?");
    $stmt->execute([$id]);

    header("Location: ../view/admin/tablas_admin_user.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmar Eliminación</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Confirmar Eliminación</h5>
                <p>¿Estás seguro de que deseas eliminar este usuario?</p>
                <form method="POST" action="">
                    <button type="submit" name="confirm_delete" class="btn btn-danger">Eliminar</button>
                    <a href="tablas_admin_user.php" class="btn btn-secondary">Cancelar</a>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
