<?php
session_start();
include '../model/db.php';

if (isset($_GET['id'])) {
    $id_cita = $_GET['id'];
} else {
    header("Location: ../view/jefe/agenda_jefe.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $conexion->prepare("DELETE FROM citas WHERE Id_Cita = :id_cita");
    $stmt->bindParam(':id_cita', $id_cita);
    $stmt->execute();

    $_SESSION['message'] = "Cita eliminada exitosamente.";
    header("Location: ../view/jefe/agenda_jefe.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmar Eliminación</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Confirmar Eliminación</h5>
                <p>¿Estás seguro de que deseas eliminar esta cita?</p>
                <form method="POST" action="">
                    <input type="hidden" name="id_cita" value="<?= $id_cita ?>">
                    <button type="submit" name="confirm_delete" class="btn btn-danger">Eliminar</button>
                    <a href="../view/jefe/agenda_jefe.php" class="btn btn-secondary">Cancelar</a>
                </form>
            </div>
        </div>
    </div>
</body>
</html>