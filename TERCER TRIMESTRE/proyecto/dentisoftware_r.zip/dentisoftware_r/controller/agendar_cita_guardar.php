<?php
include '../model/db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $numero_documento = $_POST['numero_documento'];
    $hora = $_POST['hora'];
    $fecha = $_POST['fecha'];
    $servicio_id = $_POST['servicio_id'];
    $usuario = $conexion->query("SELECT * FROM usuario WHERE numero_documento = '$numero_documento'")->fetch(PDO::FETCH_ASSOC);
    if (!$usuario) {
        die("Paciente no encontrado.");
    }
    $nombre_paciente = $usuario['nombre'];
    if ($servicio_id == 1) {
        $consultorio = 1;
        $procedimiento = 'Rehabilitación Oral';
    } elseif ($servicio_id == 2) {
        $consultorio = 2;
        $procedimiento = 'Implantes Dentales';
    } elseif ($servicio_id == 3) {
        $consultorio = 2;
        $procedimiento = 'Ortodoncia';
    } elseif ($servicio_id == 4) {
        $consultorio = 1;
        $procedimiento = 'Blanqueamiento Dental';
    } elseif ($servicio_id == 5) {
        $consultorio = 1;
        $procedimiento = 'Cirugía Molar';
    } else {
        die("Servicio no válido.");
    }
    $stmt = $conexion->prepare("INSERT INTO citas (nombre_paciente, hora, procedimiento, consultorio, fecha) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$nombre_paciente, $hora, $procedimiento, $consultorio, $fecha]);
    $_SESSION['fecha'] = $fecha;
    $_SESSION['hora'] = $hora;
    $_SESSION['consultorio'] = $consultorio;

    header('Location: ../view/paciente/confirmacion.php');
    exit();
}
?>
