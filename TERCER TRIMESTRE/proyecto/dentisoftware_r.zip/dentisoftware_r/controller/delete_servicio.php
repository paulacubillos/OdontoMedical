<?php
include '../model/db.php';
session_start();

if (!isset($_GET['id'])) {
    header("Location: ../view/admin/index_crud_servicios.php");
    exit;
}

$id = $_GET['id'];

$stmt = $conexion->prepare("DELETE FROM servicios WHERE id = ?");
$stmt->execute([$id]);

header("Location: ../view/admin/index_crud_servicios.php");
exit;
?>
