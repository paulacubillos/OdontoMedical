<?php
include '../model/db.php';
session_start();

if (!isset($_GET['id'])) {
    header("Location: ../view/admin/index_crud_servicios.php");
    exit;
}

$id = $_GET['id']; 
$servicio = $conexion->prepare("SELECT * FROM servicios WHERE id = ?");
$servicio->execute([$id]);
$servicio = $servicio->fetch(PDO::FETCH_ASSOC);

if (!$servicio) {
    header("Location: ../view/admin/index_crud_servicios.php");
    exit;
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $estado = $_POST['estado'];
    $imagen = $servicio['imagen']; 

    if (!empty($_FILES['imagen']['name'])) {
        $max_file_size = 2 * 1024 * 1024; 
        $min_file_size = 10 * 1024; 
        $file_size = $_FILES['imagen']['size'];

        if ($file_size < $min_file_size) {
            echo "La imagen es demasiado pequeña. El tamaño mínimo es 10 KB.";
            exit;
        } elseif ($file_size > $max_file_size) {
            echo "La imagen es demasiado grande. El tamaño máximo es 2 MB.";
            exit;
        }

        $ruta_imagen = '../uploads/' . basename($_FILES['imagen']['name']);
        move_uploaded_file($_FILES['imagen']['tmp_name'], $ruta_imagen);
        $imagen = $_FILES['imagen']['name'];
    }

    $stmt = $conexion->prepare("UPDATE servicios SET nombre = ?, descripcion = ?, precio = ?, estado = ?, imagen = ? WHERE id = ?");
    $stmt->execute([$nombre, $descripcion, $precio, $estado, $imagen, $id]);
    header("Location: ../view/admin/index_crud_servicios.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Servicio</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h1 class="text-center">Editar Servicio</h1>
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="nombre" class="form-label">Nombre del Servicio</label>
                        <input type="text" class="form-control" name="nombre" value="<?= htmlspecialchars($servicio['nombre'], ENT_QUOTES) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="descripcion" class="form-label">Descripción</label>
                        <textarea class="form-control" name="descripcion" rows="3" required><?= htmlspecialchars($servicio['descripcion'], ENT_QUOTES) ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="precio" class="form-label">Precio</label>
                        <input type="number" class="form-control" name="precio" step="0.01" value="<?= htmlspecialchars($servicio['precio'], ENT_QUOTES) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="estado" class="form-label">Estado</label>
                        <select class="form-select" name="estado" required>
                            <option value="activo" <?= $servicio['estado'] == 'activo' ? 'selected' : '' ?>>Activo</option>
                            <option value="inactivo" <?= $servicio['estado'] == 'inactivo' ? 'selected' : '' ?>>Inactivo</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="imagen" class="form-label">Imagen del Servicio (opcional)</label>
                        <input type="file" class="form-control" name="imagen">
                        <?php if (!empty($servicio['imagen'])): ?>
                            <p>Imagen actual: <img src="../uploads/<?= htmlspecialchars($servicio['imagen'], ENT_QUOTES) ?>" alt="Imagen del servicio" width="100"></p>
                        <?php else: ?>
                            <p>No tiene imagen</p>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Actualizar</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


