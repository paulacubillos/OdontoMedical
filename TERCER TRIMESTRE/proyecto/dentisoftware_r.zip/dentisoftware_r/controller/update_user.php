<?php
include '../model/db.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($id > 0) {
    $stmt = $conexion->prepare("SELECT * FROM usuario WHERE id = ?");
    $stmt->execute([$id]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        die("Usuario no encontrado");
    }
} else {
    die("ID de usuario inválido");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = trim($_POST['nombre']);
    $apellido = trim($_POST['apellido']);
    $tipo_documento = trim($_POST['tipo_documento']);
    $numero_documento = trim($_POST['numero_documento']);
    $edad = (int) $_POST['edad'];
    $correo = filter_var($_POST['correo'], FILTER_SANITIZE_EMAIL);
    $telefono = trim($_POST['telefono']);
    $rol = trim($_POST['rol']);

    if ($nombre && $apellido && $tipo_documento && $numero_documento && $edad && filter_var($correo, FILTER_VALIDATE_EMAIL) && $rol) {
        $stmt = $conexion->prepare("UPDATE usuario SET nombre = ?, apellido = ?, tipo_documento = ?, numero_documento = ?, edad = ?, correo = ?, telefono = ?, rol = ? WHERE id = ?");
        $stmt->execute([$nombre, $apellido, $tipo_documento, $numero_documento, $edad, $correo, $telefono, $rol, $id]);

        header("Location: ../view/admin/tablas_admin_user.php");
        exit;
    } else {
        echo "Por favor, completa todos los campos correctamente.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Usuario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Actualizar Usuario</h1>
        <form action="update_user.php?id=<?= $id; ?>" method="POST">
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre</label>
                <input type="text" class="form-control" name="nombre" value="<?= htmlspecialchars($usuario['nombre']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="apellido" class="form-label">Apellido</label>
                <input type="text" class="form-control" name="apellido" value="<?= htmlspecialchars($usuario['apellido']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="tipo_documento" class="form-label">Tipo Documento</label>
                <select id="tipo_documento" class="form-select" name="tipo_documento" required>
                    <option value="T.I" <?= $usuario['tipo_documento'] == 'T.I' ? 'selected' : ''; ?>>Tarjeta de Identidad</option>
                    <option value="C.C" <?= $usuario['tipo_documento'] == 'C.C' ? 'selected' : ''; ?>>Cédula de Ciudadanía</option>
                    <option value="Pasaporte" <?= $usuario['tipo_documento'] == 'Pasaporte' ? 'selected' : ''; ?>>Pasaporte</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="numero_documento" class="form-label">Número Documento</label>
                <input type="text" class="form-control" name="numero_documento" value="<?= htmlspecialchars($usuario['numero_documento']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="edad" class="form-label">Edad</label>
                <input type="number" class="form-control" name="edad" value="<?= (int)$usuario['edad']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="correo" class="form-label">Correo</label>
                <input type="email" class="form-control" name="correo" value="<?= htmlspecialchars($usuario['correo']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="telefono" class="form-label">Teléfono</label>
                <input type="text" class="form-control" name="telefono" value="<?= htmlspecialchars($usuario['telefono']); ?>">
            </div>
            <div class="mb-3">
                <label for="rol" class="form-label">Rol</label>
                <input type="text" class="form-control" name="rol" value="<?= htmlspecialchars($usuario['rol']); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Actualizar Usuario</button>
        </form>
    </div>
</body>
</html>



