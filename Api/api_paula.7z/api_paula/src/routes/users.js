import express from "express";
import {ActualizarUsu, borrarUsu, crearusuario, llamarUsuarios,llamarUsuId} from "../controllers/usercontroller.js";

const router = express.Router();

router.post("/users", crearusuario);

router.get("/users", llamarUsuarios);

router.get("/users/:id", llamarUsuId);

router.put("/users/:id", ActualizarUsu);

router.delete("/users/:id",borrarUsu );

export default router;