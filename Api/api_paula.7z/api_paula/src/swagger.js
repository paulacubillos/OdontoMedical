import { version } from "mongoose";
import swaggerJSDOCS from "swagger-jsdoc";
import swaggerUI from "swagger-ui-express";

const options = {
definition:{
    openapi: "3.0.0",
    info:{
        title: "API con conexion a MYSQL",
        version: "1.0.0",
        description: "Ejemplo conectanose a mysql y separando rutas",
        contact:{
            name: "API Support",
            url:"",
            email:"support@my.api.com",
        },
    },
    servers:[
        {
            url: "http://localhost:9000",
            description: "Documentacion de la api rest colectionHot",
        },
    ],
},
apis: ["./routes.js"],
};

const swaggerSpec = swaggerJSDOCS(options);
const swaggerUiOptions = (app,port) => {
    app.use("/api-docs",swaggerUI.serve,swaggerUI.setup(swaggerSpec));
    app.get("/api-docs.json", (req, res) =>{
        res.setHeader("contentType","application/json");
        res.send(swaggerSpec);
    });
    console.log(
        `Version No 1 de la documentacion estara disponible en http://localhost:${port}/api-docs`
    );
};
    
