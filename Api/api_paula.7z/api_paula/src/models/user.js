import mongoose from "mongoose";

const userSchema = mongoose.Schema({
    nombre: {
        type: String,
        required: true,
    },
    Apellido:{
        type: String,
        required: true,
    },
    Doc_identificacion:{
        type: String,
        required: true,
    },
    correo:{
        type: String,
        required: true,
    },
    Clave:{
        type: String,
        required: true,
    },
    Id_rol:{
        type: String,
        required: true,
    },
});

export default mongoose.model("User", userSchema);