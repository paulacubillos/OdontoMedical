import express from "express";
import bodyParser from "body-parser";
import swaggerJSDOCS from "./swagger.js";
import conectarBD from "./config/conexion.js";
import dotenv from "dotenv";
dotenv.config()
import userRoutes from "./routes/users.js";


const app = express();                      
app.set("port", process.env.PORT || 9000);
app.use(bodyParser.json());
app.use("/users", routes);
app.use(express.json());

var corsOptions ={
    origin: "http://localhost:5173",
    method: "GET, POST, OPTIONS, PUT, DELETE",
    optionsSuccessStatus: 200,
}
app.use(cors(corsOptions));

app.get("/", (req, res)=>{
    res.send("Bienvenido a mi API conectandome a mysql...");
});

app.use('/api', userRoutes);


app.listen(port, ()=> {
    console.log("Server listening on port", app.get(port));
    swaggerJSDOCS(app,9000);
});