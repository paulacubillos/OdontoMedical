export const crearusuario = (req, res)=>{

    const user = userSchema(req.body);
    user
    .save()
    .then((data)=>res.json(data))
    .catch((error)=>res.json({message: error}))
};

export const llamarUsuarios = (req, res)=>{
    userSchema
    .find()
    .then((data) =>res.json(data))
    .catch((error) => res.json({message: error})) 
};

export const llamarUsuId = (req, res)=>{
    const {id}= req.params;
    userSchema
    .findById(id)
    .then((data) =>res.json(data))
    .catch((error) => res.json({message: error}))
};

export const ActualizarUsu = (req, res)=>{
    const { id }= req.params;
    const { nombre, Apellido,Doc_identificacion,correo,Clave,Id_rol } = req.body;  // Actualizar usuario 
    userSchema
    .updateOne({_id: id}, {$set: {nombre,Apellido,Doc_identificacion,correo,Clave,Id_rol } })
    .then((data) =>res.json(data))
    .catch((error) => res.json({message: error}))
};

export const borrarUsu = (req, res)=>{
    const { id }= req.params;
    userSchema
    .deleteOne({_id: id})
    .then((data) =>res.json(data))
    .catch((error) => res.json({message: error})) // borrra usuario por id
};