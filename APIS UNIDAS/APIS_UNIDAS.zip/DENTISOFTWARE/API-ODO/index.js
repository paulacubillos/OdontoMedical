import express from "express";
import dotenv from "dotenv";
import port from "./src/config/bdD.js";  // Asegúrate de que el puerto se obtenga correctamente
import swaggerDocs from "./swagger.js";  // Importar la configuración de Swagger
import modelOdoPermisos from "./src/routes/rutasOdoPermisos.js";
import modelOdoHistoriales from "./src/routes/rutasOdoHistoriales.js";
import modelOdoServicios from "./src/routes/rutasOdoServicios.js";
import modelOdoUsers from "./src/routes/rutasOdoUser.js";
import modelOdoConsultorio from "./src/routes/rutasOdoConsultorios.js";
import modeloOdoDoctora from "./src/models/modeloOdoDoctora.js";
import citaRoutes from "./src/routes/rutasOdoHistoriales.js";

// Cargar las variables de entorno
dotenv.config();

// Crear la instancia de Express
const app = express();

// Middleware para parsear el cuerpo de las peticiones en formato JSON
app.use(express.json());

// Uso de prefijos únicos para las rutas para evitar conflictos
app.use('/api/', modelOdoPermisos);
app.use('/api/', modelOdoHistoriales);
app.use('/api/', modelOdoServicios);
app.use('/api/', modelOdoUsers);
app.use('/api/', modelOdoConsultorio);
app.use('/api/', modeloOdoDoctora);
app.use('/api/', citaRoutes);

// Inicializar Swagger para la documentación de la API
swaggerDocs(app, port);  // Usamos la función que configuramos en swagger.js

// Ruta principal para verificar que el servidor está corriendo
app.get("/", (req, res) => {
  res.send("<h1>ESTA ES LA API</h1>");
});

// Iniciar el servidor en el puerto especificado
app.listen(port, () => {
  console.log(`Servidor iniciado en el puerto ${port}`);
});
