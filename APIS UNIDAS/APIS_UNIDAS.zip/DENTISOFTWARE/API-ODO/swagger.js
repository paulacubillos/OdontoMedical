import swaggerJSDoc from "swagger-jsdoc";
import swaggerUi from "swagger-ui-express";

const swaggerDocs = (app, port) => {
  const swaggerOptions = {
    definition: {
      openapi: "3.0.0",
      info: {
        title: "API de Odontología",
        version: "1.0.0",
        description: "Documentación de la API para el sistema de odontología",
      },
      servers: [
        {
          url: `http://localhost:${port}/dentisoftware`
        }
      ]
    },
    apis: [
      "./src/routes/rutasOdoUser.js",       // Rutas de los usuarios
      "./src/routes/rutasOdoPermisos.js",   // Rutas de los permisos
      "./src/routes/rutasOdoServicios.js",  // Rutas de los servicios
      "./src/routes/rutasOdoHistoriales.js", // Rutas de los historiales
      "./src/routes/rutasOdoConsultorios.js", // Rutas de los consultorios
      "./src/routes/rutasOdoDoctora.js", // Rutas de la doctora
      "./src/routes/rutasOdoCitas.js" // Rutas de las citas
    ]
  };

  const swaggerSpec = swaggerJSDoc(swaggerOptions);

  // Establecer la ruta para la documentación Swagger
  app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));
  console.log(`Documentación Swagger disponible en http://localhost:${port}/api-docs`);
};

export default swaggerDocs;



