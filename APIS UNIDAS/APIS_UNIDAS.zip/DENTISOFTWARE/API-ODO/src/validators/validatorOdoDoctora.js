import Joi from "joi";

//Creamos las validaciones para cada campo
const _id = Joi.string()
  .length(24) // Asegura que tenga exactamente 24 caracteres
  .pattern(/^[a-fA-F0-9]{24}$/) // Asegura que sea una cadena de caracteres hexadecimales
  .required() // Asegura que el campo sea obligatorio
  .messages({
    "any.required": "El campo _id es requerido",
    "string.pattern.base": "El campo _id debe ser un ObjectId válido", // Mensaje para formato incorrecto
    "string.length": "El campo _id debe tener exactamente 24 caracteres",
  });
const nombre1 = Joi.string()
  .min(3)
  .max(90)
  .required()
  .pattern(/^[A-Za-záéíóúÁÉÍÓÚñÑ\s]+$/)
  .messages({
    "string.base": "El nombre debe ser un texto",
    "string.empty": "El nombre no puede estar vacío.",
    "string.min": "El nombre debe tener al menos 3 caracteres.",
    "string.max": "El nombre no puede exceder los 90 caracteres.",
    "string.pattern.base": "El nombre solo puede contener letras y espacios.",
    "any.required": "El nombre es un campo requerido",
  });
  const nombre2 = Joi.string()
  .min(3)
  .max(90)
  .pattern(/^[A-Za-záéíóúÁÉÍÓÚñÑ\s]+$/)
  .messages({
    "string.base": "El nombre debe ser un texto",
    "string.min": "El nombre debe tener al menos 3 caracteres.",
    "string.max": "El nombre no puede exceder los 90 caracteres.",
    "string.pattern.base": "El nombre solo puede contener letras y espacios.",
  });
  const apellido1 = Joi.string()
  .min(3)
  .max(90)
  .required()
  .pattern(/^[A-Za-záéíóúÁÉÍÓÚñÑ\s]+$/)
  .messages({
    "string.base": "El apellido debe ser un texto",
    "string.empty": "El apellido no puede estar vacío.",
    "string.min": "El apellido debe tener al menos 3 caracteres.",
    "string.max": "El apellido no puede exceder los 90 caracteres.",
    "string.pattern.base": "El apellido solo puede contener letras y espacios.",
    "any.required": "El apellido es un campo requerido",
  });
  const apellido2 = Joi.string()
  .min(3)
  .max(90)
  .pattern(/^[A-Za-záéíóúÁÉÍÓÚñÑ\s]+$/)
  .messages({
    "string.base": "El apellido debe ser un texto",
    "string.min": "El apellido debe tener al menos 3 caracteres.",
    "string.max": "El apellido no puede exceder los 90 caracteres.",
    "string.pattern.base": "El apellido solo puede contener letras y espacios.",
  });
  const cargo = Joi.string() // Validar que sea de tipo string
  .regex(/^[A-Za-z]+$/) // Validar que contenga solo letras
  .required() // Validar que sea requerido
  .messages({
    "string.pattern.base": "El campo cargo solo puede contener letras",
    "any.required": "El campo cargo es requerido",
  });
  const id_consultorio = Joi.number().precision(1).messages({
  "number.base": "el id del consultorio debe ser un número.",
});


//Ahora crearemos las validaciones para los métodos de la lógica

export const CreateDoctoraSchema = Joi.object({
  nombre1: nombre1.required(),
  nombre2: nombre2,
  apellido1: apellido1.required(),
  apellido2: apellido2,
  cargo: cargo.required(),
  id_consultorio: id_consultorio.required()
});

export const UpdateDoctoraSchema = Joi.object({
    nombre1: nombre1.required(),
    nombre2: nombre2,
    apellido1: apellido1.required(),
    apellido2: apellido2,
    cargo: cargo.required(),
    id_consultorio: id_consultorio.required()
});

export const BuscarDoctoraIDSchema = Joi.object({
  _id: _id.required()
});

export const DeleteDoctoraSchema = Joi.object({
  _id: _id.required()
});

