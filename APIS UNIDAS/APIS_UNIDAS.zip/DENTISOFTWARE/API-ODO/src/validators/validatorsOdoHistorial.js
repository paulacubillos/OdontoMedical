import Joi from "joi";

// Validación para el id del historial 
const id_historial = Joi.number()
  .integer()
  .positive()
  .required()
  .messages({
    "number.base": "El ID del historial debe ser un número.",
    "number.integer": "El ID del historial debe ser un número entero.",
    "number.positive": "El ID del historial debe ser un número positivo.",
    "any.required": "El campo ID del historial es requerido.",
  });

// Validación para la descripción del tratamiento 
const Descripccion_tratamiento = Joi.string()
  .min(5)
  .max(255)
  .required()
  .messages({
    "string.base": "La descripción del tratamiento debe ser un texto.",
    "string.empty": "La descripción del tratamiento no puede estar vacía.",
    "string.min": "La descripción del tratamiento debe tener al menos 5 caracteres.",
    "string.max": "La descripción del tratamiento no puede exceder los 255 caracteres.",
    "any.required": "La descripción del tratamiento es requerida.",
  });

// Validación para la fecha del tratamiento 
const Fecha_tratamiento = Joi.date()
  .iso()
  .required()
  .messages({
    "date.base": "La fecha del tratamiento debe ser una fecha válida.",
    "any.required": "La fecha del tratamiento es requerida.",
  });

// Esquema de validación para la creación de un historial clínico
const createHistorialSchema = Joi.object({
  id_historial: id_historial.required(),
  Descripccion_tratamiento: Descripccion_tratamiento.required(),
  Fecha_tratamiento: Fecha_tratamiento.required(),
});

// Esquema de validación para la actualización de un historial clínico
const updateHistorialSchema = Joi.object({
  id_historial: id_historial.required(),
  Descripccion_tratamiento: Descripccion_tratamiento.required(),
  Fecha_tratamiento: Fecha_tratamiento.required(),
});

// Esquema de validación para obtener un historial clínico por ID
const getHistorialSchema = Joi.object({
  id_historial: id_historial.required(),
});

// Esquema de validación para eliminar un historial clínico por ID
const deleteHistorialSchema = Joi.object({
  id_historial: id_historial.required(),
});

export { createHistorialSchema, updateHistorialSchema, getHistorialSchema, deleteHistorialSchema };
