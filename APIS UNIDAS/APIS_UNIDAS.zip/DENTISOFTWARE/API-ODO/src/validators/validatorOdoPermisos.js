import Joi from "joi";

const createPermisoSchema = Joi.object({
  rol: Joi.string().min(3).max(50).required().messages({
    "string.base": "El rol debe ser un texto",
    "string.min": "El rol debe tener al menos 3 caracteres",
    "string.max": "El rol no puede tener más de 50 caracteres",
    "any.required": "El rol es un campo requerido",
  }),
});

export const validateCreatePermiso = (req, res, next) => {
  const { error } = createPermisoSchema.validate(req.body, { abortEarly: false });
  if (error) {
    return res.status(400).json({
      message: "Error de validación",
      details: error.details.map((err) => err.message),
    });
  }
  next();
};
