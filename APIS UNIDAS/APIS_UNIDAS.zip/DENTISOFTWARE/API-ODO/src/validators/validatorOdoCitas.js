import Joi from "joi";

//Creamos las validaciones para cada campo
const id = Joi.string()
  .pattern(/^[0-9a-fA-F]{24}$/)
  .required()
  .messages({
    "string.pattern.base":
      "El campo ID debe ser un ObjectId válido de 24 caracteres hexadecimales.",
    "any.required": "El campo ID es requerido.",
  });

  const numero_documento= Joi.string()
  .min(3)
  .max(50)
  .required()
  .pattern(/^[A-Za-záéíóúÁÉÍÓÚñÑ\s]+$/)
  .messages({
    "string.base": "El numero_documento debe ser un texto.",
    "string.empty": "El numero_documento no puede estar vacío.",
    "string.min": "El numero_documento debe tener al menos 3 caracteres.",
    "string.max": "El numero_documento no puede exceder los 50 caracteres.",
    "string.pattern.base": "El numero_documento solo puede contener letras y espacios.",
    "any.required": "El numero_documento es un campo requerido.",
  });

const hora= Joi.string()
  .min(3)
  .max(50)
  .required()
  .pattern(/^[A-Za-záéíóúÁÉÍÓÚñÑ\s]+$/)
  .messages({
    "string.base": "La hora debe ser un texto.",
    "string.empty": "La hora no puede estar vacío.",
    "string.min": "La hora debe tener al menos 3 caracteres.",
    "string.max": "La hora no puede exceder los 50 caracteres.",
    "string.pattern.base": "La hora solo puede contener letras y espacios.",
    "any.required": "La hora es un campo requerido.",
  });

  const fecha= Joi.string()
  .min(3)
  .max(50)
  .required()
  .pattern(/^[A-Za-záéíóúÁÉÍÓÚñÑ\s]+$/)
  .messages({
    "string.base": "La fecha debe ser un texto.",
    "string.empty": "La fecha no puede estar vacío.",
    "string.min": "La fecha debe tener al menos 3 caracteres.",
    "string.max": "La fecha no puede exceder los 50 caracteres.",
    "string.pattern.base": "La fecha solo puede contener letras y espacios.",
    "any.required": "La fecha es un campo requerido.",
  });

  const servicio_id= Joi.string()
  .min(3)
  .max(50)
  .required()
  .pattern(/^[A-Za-záéíóúÁÉÍÓÚñÑ\s]+$/)
  .messages({
    "string.base": "El servicio_id debe ser un texto.",
    "string.empty": "El servicio_id no puede estar vacío.",
    "string.min": "El servicio_id debe tener al menos 3 caracteres.",
    "string.max": "El servicio_id no puede exceder los 50 caracteres.",
    "string.pattern.base": "El servicio_id solo puede contener letras y espacios.",
    "any.required": "El servicio_id es un campo requerido.",
  });

  const usuario= Joi.string()
  .min(3)
  .max(50)
  .required()
  .pattern(/^[A-Za-záéíóúÁÉÍÓÚñÑ\s]+$/)
  .messages({
    "string.base": "El usuario debe ser un texto.",
    "string.empty": "El usuario no puede estar vacío.",
    "string.min": "El usuario debe tener al menos 3 caracteres.",
    "string.max": "El usuario no puede exceder los 50 caracteres.",
    "string.pattern.base": "El usuario solo puede contener letras y espacios.",
    "any.required": "El usuario es un campo requerido.",
  });

//Ahora crearemos las validaciones para los métodos de la lógica

const createCitaSchema = Joi.object({
  numero_documento: numero_documento.required(),
  hora: hora.required(),
  fecha: fecha.required(),
  servicio_id: servicio_id.required(),
  usuario: usuario.required(),
});

const updateCitaSchema = Joi.object({
  numero_documento: numero_documento.required(),
  hora: hora.required(),
  fecha: fecha.required(),
  servicio_id: servicio_id.required(),
  usuario: usuario.required(),
});

const getCitaSchema = Joi.object({
  id: id.required(),
});

const deleteCitaSchema = Joi.object({
  id: id.required(),
});

export { createCitaSchema,
    getCitaSchema,
    updateCitaSchema,
    deleteCitaSchema};