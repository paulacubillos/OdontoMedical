import Joi from "joi";

// Definiciones de validación existentes
const id = Joi.string()
  .pattern(/^[0-9a-fA-F]{24}$/)
  .required()
  .messages({
    "string.pattern.base":
      "El campo ID debe ser un ObjectId válido de 24 caracteres hexadecimales.",
    "any.required": "El campo ID es requerido.",
  });

const nombre = Joi.string()
  .min(3)
  .max(50)
  .pattern(/^[A-Za-záéíóúÁÉÍÓÚñÑ\s]+$/)
  .required()
  .messages({
    "string.base": "El nombre debe ser un texto.",
    "string.empty": "El nombre no puede estar vacío.",
    "string.min": "El nombre debe tener al menos 3 caracteres.",
    "string.max": "El nombre no puede exceder los 50 caracteres.",
    "string.pattern.base": "El nombre solo puede contener letras y espacios.",
    "any.required": "El nombre es un campo requerido.",
  });

const apellido = Joi.string()
  .min(3)
  .max(50)
  .pattern(/^[A-Za-záéíóúÁÉÍÓÚñÑ\s]+$/)
  .required()
  .messages({
    "string.base": "El apellido debe ser un texto.",
    "string.empty": "El apellido no puede estar vacío.",
    "string.min": "El apellido debe tener al menos 3 caracteres.",
    "string.max": "El apellido no puede exceder los 50 caracteres.",
    "string.pattern.base": "El apellido solo puede contener letras y espacios.",
    "any.required": "El apellido es un campo requerido.",
  });

const Doc_identificacion = Joi.number()
  .min(1000000000) // Asegura que sea un número con 10 dígitos
  .max(9999999999) // Asegura que no exceda 10 dígitos
  .required()
  .messages({
    "number.base": "La identificación debe ser un número.",
    "number.min": "La identificación debe tener al menos 10 dígitos.",
    "number.max": "La identificación no puede exceder los 10 dígitos.",
    "any.required": "La identificación es un campo requerido.",
  });

const correo = Joi.string()
  .email()
  .required()
  .messages({
    "string.base": "El correo debe ser un texto.",
    "string.email": "El correo debe tener un formato válido.",
    "any.required": "El correo es un campo requerido.",
  });

const clave = Joi.string()
  .alphanum()
  .min(8)
  .max(16)
  .required()
  .messages({
    "string.base": "La clave debe ser un texto.",
    "string.alphanum": "La clave debe contener solo letras y números.",
    "string.min": "La clave debe tener al menos 8 caracteres.",
    "string.max": "La clave no puede exceder los 16 caracteres.",
    "any.required": "La clave es un campo requerido.",
  });

const Id_rol = Joi.string()
  .alphanum()
  .required()
  .messages({
    "string.base": "El ID del rol debe ser una cadena alfanumérica.",
    "any.required": "El ID del rol es un campo requerido.",
  });

// Esquema para crear usuario
const createUserSchema = Joi.object({
  nombre,
  apellido,
  Doc_identificacion,
  correo,
  clave,
  Id_rol,
});

// Esquema para actualizar usuario
const updateUserSchema = Joi.object({
  nombre: nombre.optional(),
  apellido: apellido.optional(),
  Doc_identificacion: Doc_identificacion.optional(),
  correo: correo.optional(),
  clave: clave.optional(),
  Id_rol: Id_rol.optional(),
});

// Esquema para obtener usuario por ID
const getUserSchema = Joi.object({
  id,
});

// Esquema para eliminar usuario por ID
const deleteUserSchema = Joi.object({
  id,
});

// Esquema para crear servicio
const createServicioSchema = Joi.object({
  nombre,
  Doc_identificacion,
});

// Exportación de los esquemas
export {
  createUserSchema,
  getUserSchema,
  updateUserSchema,
  deleteUserSchema,
  createServicioSchema,
};
