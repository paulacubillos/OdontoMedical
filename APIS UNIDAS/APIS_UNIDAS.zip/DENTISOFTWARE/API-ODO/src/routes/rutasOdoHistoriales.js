import express from "express";
import { 
    createHistorial, 
    getHistorial, 
    getHistorialById, 
    updateHistorial, 
    deleteHistorial 
} from "../controller/controlOdoHistoriales.js";

const router = express.Router();

/**
 * @swagger
 * tags:
 *   - name: Historiales
 *     description: Operaciones relacionadas con los historiales odontológicos
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     Historial:
 *       type: object
 *       properties:
 *         id_historial:
 *           type: string
 *           description: ID único del historial odontológico
 *         nombre:
 *           type: string
 *           description: Nombre del paciente
 *         edad:
 *           type: integer
 *           description: Edad del paciente
 *         genero:
 *           type: string
 *           description: Género del paciente
 *         descripcion_tratamiento:
 *           type: string
 *           description: Descripción del tratamiento realizado
 *         fecha_tratamiento:
 *           type: string
 *           format: date
 *           description: Fecha del tratamiento
 *       required:
 *         - nombre
 *         - edad
 *         - genero
 *         - descripcion_tratamiento
 *         - fecha_tratamiento
 */

/**
 * @swagger
 * /historial:
 *   post:
 *     summary: Crear un nuevo historial odontológico
 *     description: Crear un historial de odontología con detalles como nombre, edad y género del paciente.
 *     tags: [Historiales]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Historial'
 *     responses:
 *       201:
 *         description: Historial creado exitosamente
 *       400:
 *         description: Error en la solicitud
 */
router.post("/historial", createHistorial);

/**
 * @swagger
 * /historial:
 *   get:
 *     summary: Obtener todos los historiales odontológicos
 *     description: Obtener una lista de todos los historiales registrados.
 *     tags: [Historiales]
 *     responses:
 *       200:
 *         description: Lista de historiales
 *       500:
 *         description: Error del servidor
 */
router.get("/historial", getHistorial);

/**
 * @swagger
 * /historial/{id}:
 *   get:
 *     summary: Obtener un historial odontológico por ID
 *     description: Obtener un historial específico por su ID.
 *     tags: [Historiales]
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         description: El ID del historial odontológico a recuperar
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Historial encontrado exitosamente
 *       404:
 *         description: Historial no encontrado
 */
router.get("/historial/:id", getHistorialById);

/**
 * @swagger
 * /historial/{id}:
 *   put:
 *     summary: Actualizar un historial odontológico
 *     description: Actualizar los detalles de un historial odontológico, incluyendo nombre, edad y género.
 *     tags: [Historiales]
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         description: El ID del historial a actualizar
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Historial'
 *     responses:
 *       200:
 *         description: Historial actualizado exitosamente
 *       400:
 *         description: Error en la solicitud de actualización
 *       404:
 *         description: Historial no encontrado
 */
router.put("/historial/:id", updateHistorial);

/**
 * @swagger
 * /historial/{id}:
 *   delete:
 *     summary: Eliminar un historial odontológico
 *     description: Eliminar un historial odontológico específico por su ID.
 *     tags: [Historiales]
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         description: El ID del historial a eliminar
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Historial eliminado exitosamente
 *       404:
 *         description: Historial no encontrado
 */
router.delete("/historial/:id", deleteHistorial);

export default router;
