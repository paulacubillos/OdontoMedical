import express from "express";
import { 
    CreateDoctora, 
    BuscarDoctora, 
    BuscarDoctoraID, 
    UpdateDoctora, 
    DeleteDoctora 
} from "../controller/controlOdoDoctora.js";

const router = express.Router();  // Aquí se define correctamente el enrutador

/**
 * @swagger
 * components:
 *   schemas:
 *     Doctora:
 *       type: object
 *       properties:
 *         _id:
 *           type: string
 *           description: ID único de la doctora
 *         nombre1:
 *           type: string
 *           description: Primer nombre de la doctora
 *         nombre2:
 *           type: string
 *           description: Segundo nombre de la doctora
 *         apellido1:
 *           type: string
 *           description: Primer apellido de la doctora
 *         apellido2:
 *           type: string
 *           description: Segundo apellido de la doctora
 *         cargo:
 *           type: string
 *           description: Cargo de la doctora
 *         id_consultorio:
 *           type: number
 *           description: ID del consultorio asociado
 */

/**
 * @swagger
 * /doctora:
 *   get:
 *     summary: Retorna los registros de la entidad Doctora
 *     description: Retorna los registros de todas las doctoras
 *     tags:
 *       - Doctora
 *     responses:
 *       200:
 *         description: Lista de doctoras
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Doctora'
 */
router.get("/doctora", BuscarDoctora);

/**
 * @swagger
 * /doctora/{_id}:
 *   get:
 *     summary: Retorna el registro por ID de la entidad Doctora
 *     description: Retorna el registro de una doctora por su ID
 *     tags:
 *       - Doctora
 *     parameters:
 *       - in: path
 *         name: _id
 *         required: true
 *         description: ID de la doctora a buscar
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Detalles de la doctora
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Doctora'
 *       404:
 *         description: No se encontró la doctora con ese ID
 */
router.get("/doctora/:_id", BuscarDoctoraID);

/**
 * @swagger
 * /doctora:
 *   post:
 *     summary: Registra una nueva doctora
 *     description: Crea un nuevo registro de doctora
 *     tags:
 *       - Doctora
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               nombre1:
 *                 type: string
 *               nombre2:
 *                 type: string
 *               apellido1:
 *                 type: string
 *               apellido2:
 *                 type: string
 *               cargo:
 *                 type: string
 *               id_consultorio:
 *                 type: number
 *     responses:
 *       201:
 *         description: Registro de doctora creado con éxito
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Doctora'
 */
router.post("/doctora", CreateDoctora);

/**
 * @swagger
 * /doctora/{_id}:
 *   put:
 *     summary: Actualiza los datos de una doctora
 *     description: Actualiza el registro de una doctora en la base de datos
 *     tags:
 *       - Doctora
 *     parameters:
 *       - in: path
 *         name: _id
 *         required: true
 *         description: ID de la doctora a actualizar
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               nombre1:
 *                 type: string
 *               nombre2:
 *                 type: string
 *               apellido1:
 *                 type: string
 *               apellido2:
 *                 type: string
 *               cargo:
 *                 type: string
 *               id_consultorio:
 *                 type: number
 *     responses:
 *       200:
 *         description: Doctora actualizada correctamente
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Doctora'
 *       404:
 *         description: No se encontró la doctora con ese ID
 *       400:
 *         description: Error en los datos enviados para la actualización
 */
router.put("/doctora/:_id", UpdateDoctora);

/**
 * @swagger
 * /doctora/{_id}:
 *   delete:
 *     summary: Elimina una doctora de la base de datos
 *     description: Elimina el registro de una doctora por su ID
 *     tags:
 *       - Doctora
 *     parameters:
 *       - in: path
 *         name: _id
 *         required: true
 *         description: ID de la doctora a eliminar
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Doctora eliminada correctamente
 *       404:
 *         description: No se encontró la doctora con ese ID
 */
router.delete("/doctora/:_id", DeleteDoctora);

export default router;