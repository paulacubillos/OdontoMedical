import express from "express";
import { 
    ActualizarConsultorio, 
    borrarConsultorio, 
    crearconsultorio, 
    llamarConsultorio, 
    llamarConsultorioId 
} from "../controller/controlOdoConsultorios.js";

const modelOdoConsultorio = express.Router();

/**
 * @swagger
 * openapi: 3.0.0
 * info:
 *   title: API de Consultorios
 *   version: 1.0.0
 *   description: API para gestionar los consultorios en la plataforma
 * paths:
 *   /consultorios:
 *     post:
 *       summary: Crear un nuevo consultorio.
 *       description: Permite crear un nuevo consultorio en la plataforma.
 *       tags:
 *         - Consultorios
 *       requestBody:
 *         required: true
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Consultorio'
 *       responses:
 *         201:
 *           description: Consultorio creado exitosamente
 *         400:
 *           description: Error en la información del Consultorio
 *     get:
 *       summary: Obtener todos los consultorios
 *       description: Devuelve una lista con todos los consultorios existentes.
 *       tags:
 *         - Consultorios
 *       responses:
 *         200:
 *           description: Lista de consultorios
 *           content:
 *             application/json:
 *               schema:
 *                 type: array
 *                 items:
 *                   $ref: '#/components/schemas/Consultorio'
 *   /consultorios/{id}:
 *     get:
 *       summary: Obtener un consultorio por ID
 *       description: Devuelve los detalles de un consultorio específico usando su ID.
 *       tags:
 *         - Consultorios
 *       parameters:
 *         - in: path
 *           name: id
 *           required: true
 *           description: ID del consultorio que se desea obtener
 *           schema:
 *             type: string
 *       responses:
 *         200:
 *           description: Detalles del consultorio
 *           content:
 *             application/json:
 *               schema:
 *                 $ref: '#/components/schemas/Consultorio'
 *         404:
 *           description: Consultorio no encontrado
 *     put:
 *       summary: Actualizar un consultorio existente
 *       description: Permite actualizar los datos de un consultorio ya existente.
 *       tags:
 *         - Consultorios
 *       parameters:
 *         - in: path
 *           name: id
 *           required: true
 *           description: ID del consultorio que se desea actualizar
 *           schema:
 *             type: string
 *       requestBody:
 *         required: true
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Consultorio'
 *       responses:
 *         200:
 *           description: Consultorio actualizado exitosamente
 *         400:
 *           description: Error en los datos del consultorio
 *         404:
 *           description: Consultorio no encontrado
 *     delete:
 *       summary: Eliminar un consultorio
 *       description: Permite eliminar un consultorio por su ID.
 *       tags:
 *         - Consultorios
 *       parameters:
 *         - in: path
 *           name: id
 *           required: true
 *           description: ID del consultorio a eliminar
 *           schema:
 *             type: string
 *       responses:
 *         200:
 *           description: Consultorio eliminado exitosamente
 *         404:
 *           description: Consultorio no encontrado
 * components:
 *   schemas:
 *     Consultorio:
 *       type: object
 *       properties:
 *         id_consultorio:
 *           type: string
 *           description: "ID del consultorio"
 *         nombre_consultorio:
 *           type: string
 *           description: "Nombre del consultorio"
 *         doctor_acargo:
 *           type: string
 *           description: "Nombre del doctor a cargo del consultorio"
 *       required:
 *         - id_consultorio
 *         - nombre_consultorio
 *         - doctor_acargo
 */
export default modelOdoConsultorio;

