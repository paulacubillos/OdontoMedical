import express from "express";
import { ActualizarCita, borrarCita, crearcita, llamarCita, llamarCitaId } from "../controllers/controlOdoCitas.js";

const router = express.Router();

/**
 * @swagger
 * tags:
 *   - name: Citas
 *     description: Endpoints para manejar citas
 */
/**
 * @swagger
 * components:
 *   schemas:
 *     Cita:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           description: ID único de la cita
 *         fecha:
 *           type: string
 *           format: date-time
 *           description: Fecha y hora de la cita
 *         paciente:
 *           type: string
 *           description: Nombre del paciente
 *         doctor:
 *           type: string
 *           description: Nombre del doctor asignado
 *         motivo:
 *           type: string
 *           description: Motivo de la cita
 *       required:
 *         - fecha
 *         - paciente
 *         - doctor
 *       example:
 *         id: "63f4eede9e5e1a2d9c4f8301"
 *         fecha: "2024-11-21T10:30:00Z"
 *         paciente: "Juan Pérez"
 *         doctor: "Dra. Ana Martínez"
 *         motivo: "Consulta odontológica"
 */
/**
 * @swagger
 * /citas:
 *   post:
 *     summary: Crear una nueva cita.
 *     description: Permite crear una nueva cita.
 *     tags:
 *       - Citas
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Cita'
 *     responses:
 *       201:
 *         description: Cita creada exitosamente
 *       400:
 *         description: Error en la información de la cita
 */
router.post("/citas", crearcita);

/**
 * @swagger
 * /citas:
 *   get:
 *     summary: Obtener todas las citas
 *     description: Devuelve una lista de todas las citas.
 *     tags:
 *       - Citas
 *     responses:
 *       200:
 *         description: Lista de citas
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Cita'
 */
router.get("/citas", llamarCita);

/**
 * @swagger
 * /citas/{id}:
 *   get:
 *     summary: Obtener una cita por ID
 *     description: Devuelve los detalles de una cita específico usando su ID.
 *     tags:
 *       - Citas
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID de la cita que se desea obtener
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Detalles de la cita
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Cita'
 *       404:
 *         description: cita no encontrada
 */
router.get("/citas/:id", llamarCitaId);

/**
 * @swagger
 * /citas/{id}:
 *   put:
 *     summary: Actualizar una cita existente
 *     description: Permite actualizar los datos de una cita existente.
 *     tags:
 *       - Citas
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID de la cita que se desea actualizar
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Cita'
 *     responses:
 *       200:
 *         description: Cita actualizada exitosamente
 *       400:
 *         description: Error en los datos de la cita
 *       404:
 *         description: cita no encontrada
 */
router.put("/citas/:id", ActualizarCita);

/**
 * @swagger
 * /citas/{id}:
 *   delete:
 *     summary: Eliminar una cita
 *     description: Permite eliminar una cita por su ID.
 *     tags:
 *       - Citas
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID de la cita a eliminar
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Cita eliminada exitosamente
 *       404:
 *         description: Cita no encontrada
 */
router.delete("/citas/:id", borrarCita);

export default router;
