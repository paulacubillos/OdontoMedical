import userSchema from "../models/modelOdoUser.js";
import { validatorHandler } from "../middleware/validator.handler.js";
import {
  createUserSchema,
  getUserSchema,
  updateUserSchema,
  deleteUserSchema,
} from "../validators/validatorOdoUser.js";

// Crear un nuevo usuario
export const crearusuario = [
  validatorHandler(createUserSchema, "body"),
  async (req, res) => {
    try {
      const user = new userSchema(req.body);
      const data = await user.save();
      res.status(201).json(data); // Código 201 indica que se creó un nuevo recurso
    } catch (error) {
      if (error.code === 11000) { // Error de campo único duplicado
        return res.status(400).json({ message: "El correo o documento ya existe" });
      }
      res.status(500).json({ message: error.message });
    }
  },
];

// Obtener todos los usuarios
export const llamarUsuarios = async (req, res) => {
  try {
    const data = await userSchema.find(); // Buscar todos los documentos en la colección
    res.json(data);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Obtener un usuario por ID
export const llamarUsuId = [
  validatorHandler(getUserSchema, "params"),
  async (req, res) => {
    const { id } = req.params;
    try {
      const user = await userSchema.findById(id);
      if (!user) {
        return res.status(404).json({ message: "Usuario no encontrado" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  },
];

// Actualizar un usuario
export const ActualizarUsu = [
  validatorHandler(getUserSchema, "params"),
  validatorHandler(updateUserSchema, "body"),
  async (req, res) => {
    const { id } = req.params;
    const { nombre, apellido, Doc_identificacion, correo, clave, Id_rol } = req.body;

    try {
      const userUpdate = await userSchema.findByIdAndUpdate(
        id,
        { nombre, apellido, Doc_identificacion, correo, clave, Id_rol },
        { new: true, runValidators: true } // Devuelve el documento actualizado y valida el esquema
      );

      if (!userUpdate) {
        return res.status(404).json({ message: "Usuario no encontrado" });
      }

      res.status(200).json({ message: "Usuario actualizado correctamente", data: userUpdate });
    } catch (error) {
      if (error.code === 11000) {
        return res.status(400).json({ message: "El correo o documento ya existe" });
      }
      res.status(500).json({ message: error.message });
    }
  },
];

// Eliminar un usuario
export const borrarUsu = [
  validatorHandler(deleteUserSchema, "params"),
  async (req, res) => {
    const { id } = req.params;
    try {
      const result = await userSchema.findByIdAndDelete(id);
      if (!result) {
        return res.status(404).json({ message: "Usuario no encontrado" });
      }
      res.status(200).json({ message: "Usuario eliminado correctamente" });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  },
];
