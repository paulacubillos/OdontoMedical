import doctoraSchema from "../models/modeloOdoDoctora.js";
import { validatorHandler } from "../middleware/validator.handler.js";
import {
  CreateDoctoraSchema,
  UpdateDoctoraSchema,
  BuscarDoctoraIDSchema,
  DeleteDoctoraSchema,
} from "../validator/doctoraValidator.js";

export const CreateDoctora = [
  validatorHandler(CreateDoctoraSchema, "body"),
  async (req, res) => {
    const doctora = doctoraSchema(req.body);
    await doctora
      .save()
      .then((data) => res.status(201).json(data))
      .catch((error) => res.status(500).json({ message: error.message }));
  }
];
export const BuscarDoctora = (req, res) => {
  doctoraSchema
    .find()
    .then((data) => res.json(data))
    .catch((error) => res.json({ message: error }))
}
export const BuscarDoctoraID = [
  validatorHandler(BuscarDoctoraIDSchema, "params"),
  async (req, res) => {
    const { _id } = req.params;
    console.log(_id);
    try {
      const doctora = await doctoraSchema.findById(_id); //Metodo usado para buscar un documento de una coleccion
      if (!doctora) {
        return resp.status(404).json({
          message: "Usuario no encontrado",
        });
      }
      res.json(doctora);
    } catch (error) {
      res.status(500).json({
        message: error.message,
      });
    }
  },
];
export const UpdateDoctora = [
  validatorHandler(BuscarDoctoraIDSchema, "params"),
  validatorHandler(UpdateDoctoraSchema, "body"),
  async (req, res) => {
    const { _id } = req.params;
    const { nombre1, nombre2, apellido1, apellido2, cargo, id_consultorio } = req.body;
    try {
      const doctoraUpdate = await doctoraSchema.updateOne(
        { _id: _id },
        { $set: { nombre1, nombre2, apellido1, apellido2, cargo, id_consultorio } }
      );
      if (doctoraUpdate.matchedCount === 0) {
        return res.status(404).json({ message: "Usuario no encontrado" });
      }
      if (doctoraUpdate.modifiedCount === 0) {
        return res.status(400).json({ message: "No se realizaron cambios" });
      }
      res.status(200).json({ message: "Usuario actualizado correctamente" });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  },
];
export const DeleteDoctora = [
  validatorHandler(DeleteDoctoraSchema, "params"),
  async (req, res) => {
    const { _id } = req.params;
    try {
      const result = await doctoraSchema.deleteOne({ _id: _id });
      if (result.deletedCount === 1) {
        res.status(404).json({ message: "Usuario eliminado con exito" })
      }
      res.status(200).json({ message: "Usuario no encontrado" });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  },
];