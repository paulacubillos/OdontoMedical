import permisosSchema from "../models/modelOdoPermisos.js";

// Crear un nuevo permiso
export const createPermiso = (req, resp) => {
    const { id_permiso, rol } = req.body;

    // Validar que los campos no sean vacíos
    if (!id_permiso || !rol) {
        return resp.status(400).json({
            message: "Los campos id_permiso y rol son requeridos",
        });
    }

    // Validar el rol
    if (![1, 2, 3, 4].includes(rol)) {
        return resp.status(400).json({
            message: "El rol debe ser 1 (ADMIN), 2 (JEFE), 3 (RECEPCIONISTA) o 4 (PACIENTE)",
        });
    }

    const permiso = new permisosSchema(req.body);
    permiso
        .save()
        .then((data) => resp.status(201).json(data))
        .catch((error) => resp.status(500).json({ message: error.message }));
};

// Obtener todos los permisos
export const getPermisos = (req, resp) => {
    permisosSchema
        .find()
        .then((data) => resp.status(200).json(data))
        .catch((error) => resp.status(500).json({ message: error.message }));
};

// Obtener permiso por id_permiso
export const getPermisoById = (req, resp) => {
    const { id } = req.params;
    permisosSchema
        .findOne({ id_permiso: id })
        .then((data) => {
            if (data) {
                resp.status(200).json(data);
            } else {
                resp.status(404).json({ message: "Permiso no encontrado" });
            }
        })
        .catch((error) => resp.status(500).json({ message: error.message }));
};

// Actualizar permiso por id_permiso
export const updatePermiso = (req, resp) => {
    const { id } = req.params;
    const { rol } = req.body;

    if (![1, 2, 3, 4].includes(rol)) {
        return resp.status(400).json({
            message: "El rol debe ser 1 (ADMIN), 2 (JEFE), 3 (RECEPCIONISTA) o 4 (PACIENTE)",
        });
    }

    permisosSchema
        .updateOne({ id_permiso: id }, { $set: { rol } })
        .then((data) => {
            if (data.nModified > 0) {
                resp.status(200).json({ message: "Permiso actualizado exitosamente" });
            } else {
                resp.status(404).json({ message: "Permiso no encontrado" });
            }
        })
        .catch((error) => resp.status(500).json({ message: error.message }));
};

// Eliminar permiso por id_permiso
export const deletePermiso = (req, resp) => {
    const { id } = req.params;
    permisosSchema
        .deleteOne({ id_permiso: id })
        .then((data) => {
            if (data.deletedCount > 0) {
                resp.status(200).json({ message: "Permiso eliminado exitosamente" });
            } else {
                resp.status(404).json({ message: "Permiso no encontrado" });
            }
        })
        .catch((error) => resp.status(500).json({ message: error.message }));
};
