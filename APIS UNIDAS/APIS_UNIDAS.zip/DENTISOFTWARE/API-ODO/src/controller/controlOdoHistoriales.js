import historialSchema from "../models/modelOdoHistoriales.js";

// Crear un nuevo historial
export const createHistorial = (req, resp) => {
    const { id_historial, Descripccion_tratamiento, Fecha_tratamiento } = req.body;

    // Validar que los campos no sean vacíos
    if (!id_historial || !Descripccion_tratamiento || !Fecha_tratamiento) {
        return resp.status(400).json({
            message: "Todos los campos son requeridos",
        });
    }

    const Historial = new historialSchema(req.body);
    Historial
        .save()
        .then((data) => resp.status(201).json(data))
        .catch((error) => resp.status(500).json({ message: error.message }));
};

// Obtener todos los historiales
export const getHistorial = (req, resp) => {
    historialSchema
        .find()
        .then((data) => resp.status(200).json(data))
        .catch((error) => resp.status(500).json({ message: error.message }));
};

// Obtener historial por id_historial
export const getHistorialById = (req, resp) => {
    const { id } = req.params;
    historialSchema
        .findOne({ id_historial: id })
        .then((data) => {
            if (data) {
                resp.status(200).json(data);
            } else {
                resp.status(404).json({ message: "Historial no encontrado" });
            }
        })
        .catch((error) => resp.status(500).json({ message: error.message }));
};

// Actualizar historial por id_historial
export const updateHistorial = (req, resp) => {
    const { id } = req.params;
    const { Descripccion_tratamiento, Fecha_tratamiento } = req.body;

    if (!Descripccion_tratamiento || !Fecha_tratamiento) {
        return resp.status(400).json({ message: "Todos los campos son requeridos" });
    }

    historialSchema
        .updateOne({ id_historial: id }, { $set: { Descripccion_tratamiento, Fecha_tratamiento } })
        .then((data) => {
            if (data.nModified > 0) {
                resp.status(200).json({ message: "Historial actualizado exitosamente" });
            } else {
                resp.status(404).json({ message: "Historial no encontrado" });
            }
        })
        .catch((error) => resp.status(500).json({ message: error.message }));
};

// Eliminar historial por id_historial
export const deleteHistorial = (req, resp) => {
    const { id } = req.params;
    historialSchema
        .deleteOne({ id_historial: id })
        .then((data) => {
            if (data.deletedCount > 0) {
                resp.status(200).json({ message: "Historial eliminado exitosamente" });
            } else {
                resp.status(404).json({ message: "Historial no encontrado" });
            }
        })
        .catch((error) => resp.status(500).json({ message: error.message }));
};
