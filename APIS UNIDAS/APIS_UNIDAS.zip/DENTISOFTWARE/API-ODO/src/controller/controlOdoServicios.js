import servSchema from "../models/modelOdoServicios.js";
import { validatorHandler } from "../middleware/validator.handler.js";
import {
  createServicioSchema,
  getServicioIdSchema,
  updateServicioSchema,
  deleteServicioSchema,
} from "../validators/validatorOdoServicios.js";

export const createServicio = [
  validatorHandler(createServicioSchema, "body"),
  async (req, res) => {
    try {
      const servicio = new servSchema(req.body);
      const data = await servicio.save();
      res.status(201).json(data);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  },
];

export const getServicio = (req, resp) => {
  servSchema
    .find()
    .then((data) => resp.json(data))
    .catch((error) => resp.status(500).json({ message: error.message }));
};

export const getServicioId = [
  validatorHandler(getServicioIdSchema, "params"),
  async (req, resp) => {
    const { id } = req.params;
    try {
      const servicio = await servSchema.findById(id);
      if (!servicio) {
        return resp.status(404).json({ message: "Categoria no encontrada" });
      }
      resp.json(servicio);
    } catch (error) {
      resp.status(500).json({ message: error.message });
    }
  },
];

export const updateServicio = [
  validatorHandler(getServicioIdSchema, "params"),
  validatorHandler(updateServicioSchema, "body"),
  async (req, resp) => {
    const { id } = req.params;
    const { Nombre, descripcion, precio } = req.body;
    try {
      const ServUpdate = await servSchema.updateOne(
        { _id: id },
        { $set: { Nombre, descripcion, precio } }
      );
      if (ServUpdate.matchedCount === 0) {
        return resp.status(404).json({ message: "Categoria no encontrada" });
      }
      if (ServUpdate.modifiedCount === 0) {
        return resp
          .status(400)
          .json({ message: "No se realizaron cambios en la categoria" });
      }
      resp.status(200).json({ message: "Categoria actualizada correctamente" });
    } catch (error) {
      resp.status(500).json({ message: error.message });
    }
  },
];

export const deleteServicio = [
  validatorHandler(deleteServicioSchema, "params"),
  async (req, resp) => {
    const { id } = req.params;
    try {
      const result = await servSchema.deleteOne({ _id: id });
      if (result.deletedCount === 0) {
        resp.status(404).json({ message: "Categoria no encontrada" });
      }
      resp.status(200).json({ message: "Categoria eliminada correctamente" });
    } catch (error) {
      resp.status(500).json({ message: error.message });
    }
  },
];
