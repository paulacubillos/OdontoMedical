import citaSchema from "../models/modelOdoCitas.js";
import { validatorHandler } from "../middleware/validator.handler.js";
import {
  createCitaSchema,
  getCitaSchema,
  updateCitaSchema,
  deleteCitaSchema,
} from "../validators/validatorOdoCitas.js";

// Crear una nueva Cita 
export const crearcita = [
  validatorHandler(createCitaSchema, "body"),
  async (req, res) => {
    try {
      const cita = new citaSchema(req.body);
      const data = await cita.save();
      res.status(201).json(data); // Código 201 indica que se creó un nuevo recurso
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  },
];

// Obtener todas las Citas
export const llamarCita = async (req, res) => {
  try {
    const data = await citaSchema.find(); // Buscar todos los documentos en la colección
    res.json(data);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Obtener una cita por ID
export const llamarCitaId = [
  validatorHandler(getCitaSchema, "params"),
  async (req, res) => {
    const { id } = req.params;
    try {
      const cita = await citaSchema.findById(id); // Cambiado `markSchema` a `userSchema`
      if (!cita) {
        return res.status(404).json({ message: "Cita no encontrada" });
      }
      res.json(cita);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  },
];

// Actualizar una cita
export const ActualizarCita = [
  validatorHandler(getCitaSchema, "params"),
  validatorHandler(updateCitaSchema, "body"),
  async (req, res) => {
    const { id } = req.params;
    const { numero_documento, hora, fecha, servicio_id, usuario } = req.body;

    try {
      // Obtener la cita actual
      const currentCita = await citaSchema.findById(id);
      if (!currentCita) {
        return res.status(404).json({ message: "Cita no encontrada" });
      }

      // Actualizar Cita
      const citaUpdate = await citaSchema.updateOne(
        { _id: id },
        { $set: { numero_documento, hora, fecha, servicio_id, usuario } }
      );

      if (citaUpdate.matchedCount === 0) {
        return res.status(404).json({ message: "Cita no encontrada" });
      }
      if (citaUpdate.modifiedCount === 0) {
        return res.status(400).json({ message: "No se realizaron cambios en la Cita" });
      }
      res.status(200).json({ message: "Cita actualizada correctamente" });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  },
];

// Eliminar una cita
export const borrarCita = [
  validatorHandler(deleteCitaSchema, "params"),
  async (req, res) => {
    const { id } = req.params;
    try {
      const result = await citaSchema.deleteOne({ _id: id });
      if (result.deletedCount === 0) {
        return res.status(404).json({ message: "Cita no encontrada" });
      }
      res.status(200).json({ message: "Cita eliminada correctamente" });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  },
];
