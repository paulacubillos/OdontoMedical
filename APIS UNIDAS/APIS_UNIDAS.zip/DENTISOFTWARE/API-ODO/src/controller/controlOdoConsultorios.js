import consultorioSchema from "../models/modelOdoConsultorios.js";
import { validatorHandler } from "../middleware/validator.handler.js";
import {
  createConsultorioSchema,
  getConsultorioSchema,
  updateConsultorioSchema,
  deleteConsultorioSchema,
} from "../validators/validatorOdoConsultorios.js";

// Crear un nuevo Consultorio
export const crearconsultorio = [
  validatorHandler(createConsultorioSchema, "body"),
  async (req, res) => {
    try {
      const consultorio = new consultorioSchema(req.body);
      const data = await consultorio.save();
      res.status(201).json(data); // Código 201 indica que se creó un nuevo recurso
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  },
];

// Obtener todos los Consultorio
export const llamarConsultorio = async (req, res) => {
  try {
    const data = await consultorioSchema.find(); // Buscar todos los documentos en la colección
    res.json(data);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Obtener un Consultorio por ID
export const llamarConsultorioId = [
  validatorHandler(getConsultorioSchema, "params"),
  async (req, res) => {
    const { id } = req.params;
    try {
      const consultorio = await consultorioSchema.findById(id); // Cambiado `markSchema` a `userSchema`
      if (!consultorio) {
        return res.status(404).json({ message: "Consultorio no encontrado" });
      }
      res.json(consultorio);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  },
];

// Actualizar un usuario
export const ActualizarConsultorio = [
  validatorHandler(getConsultorioSchema, "params"),
  validatorHandler(updateConsultorioSchema, "body"),
  async (req, res) => {
    const { id } = req.params;
    const { id_consultorio, nombre_consultorio, doctor_acargo } = req.body;

    try {
      // Obtener el usuario actual
      const currentConsultorio = await consultorioSchema.findById(id);
      if (!currentConsultorio) {
        return res.status(404).json({ message: "Consultorio no encontrado" });
      }

      // Actualizar Consultorio
      const consultorioUpdate = await consultorioSchema.updateOne(
        { _id: id },
        { $set: { id_consultorio, nombre_consultorio, doctor_acargo } }
      );

      if (consultorioUpdate.matchedCount === 0) {
        return res.status(404).json({ message: "Consultorio no encontrado" });
      }
      if (consultorioUpdate.modifiedCount === 0) {
        return res.status(400).json({ message: "No se realizaron cambios en el Consultorio" });
      }
      res.status(200).json({ message: "Consultorio actualizado correctamente" });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  },
];

// Eliminar un Consultorio
export const borrarConsultorio = [
  validatorHandler(deleteConsultorioSchema, "params"),
  async (req, res) => {
    const { id } = req.params;
    try {
      const result = await consultorioSchema.deleteOne({ _id: id });
      if (result.deletedCount === 0) {
        return res.status(404).json({ message: "Consultorio no encontrado" });
      }
      res.status(200).json({ message: "Consultorio eliminado correctamente" });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  },
];
