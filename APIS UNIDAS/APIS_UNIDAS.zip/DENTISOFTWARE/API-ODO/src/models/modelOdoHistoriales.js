import mongoose from "mongoose";

// Definición del esquema para los historiales
const historialSchema = mongoose.Schema(
  {
    id_historial: {
      type: Number,
      required: true, // El campo es obligatorio
      unique: true,   // El id_historial debe ser único
    },
    Descripccion_tratamiento: {
      type: String,
      required: true, // El campo es obligatorio
      trim: true,     // Elimina espacios al principio y al final
    },
    Fecha_tratamiento: {
      type: Date,
      required: true, // El campo es obligatorio
      default: Date.now, // Si no se proporciona, la fecha actual será la predeterminada
    },
  },
  {
    timestamps: true, // Para que Mongoose añada createdAt y updatedAt automáticamente
  }
);

// Creación del modelo
const Historial = mongoose.model("Historial", historialSchema);

export default Historial;
