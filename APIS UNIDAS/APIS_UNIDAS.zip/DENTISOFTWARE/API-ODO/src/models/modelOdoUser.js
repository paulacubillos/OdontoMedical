import mongoose from "mongoose";

const userSchema = mongoose.Schema(
    {
        nombre: {
            type: String,
            required: [true, "El nombre es obligatorio"],
        },
        apellido: {
            type: String,
            required: [true, "El apellido es obligatorio"],
        },
        Doc_identificacion: {
            type: String,
            required: [true, "El documento de identificación es obligatorio"],
            unique: true,
        },
        correo: {
            type: String,
            required: [true, "El correo es obligatorio"],
            unique: true,
            match: [
                /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
                "El correo no tiene un formato válido",
            ],
        },
        clave: {
            type: String,
            required: [true, "La clave es obligatoria"],
            minlength: [8, "La clave debe tener al menos 8 caracteres"],
        },
        Id_rol: {
            type: Number,
            required: [true, "El rol es obligatorio"],
            enum: {
                values: [1, 2, 3, 4], // Define los roles permitidos
                message: "El rol debe ser uno de los valores: 1 (Admin), 2 (Jefe), 3 (Recepcionista), 4 (Paciente)",
            },
        },
    },
    {
        timestamps: true, // Agrega createdAt y updatedAt automáticamente
    }
);

export default mongoose.model("User", userSchema);
