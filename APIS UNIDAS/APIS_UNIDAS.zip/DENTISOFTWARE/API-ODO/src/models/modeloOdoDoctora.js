import mongoose from "mongoose";

const doctoraSchema = mongoose.Schema({
    nombre1: {
        type: String,
        required: true,
    },
    nombre2: {
        type: String,
        required: false,
    },
    apellido1: {
        type: String,
        required: true,
    },
    apellido2: {
        type: String,
        required: false,
    },
    cargo:{
        type: String,
        required: true,
    },
    id_consultorio:{
        type: Number,
        required: true,
    },
});

export default mongoose.model("Doctora", doctoraSchema);