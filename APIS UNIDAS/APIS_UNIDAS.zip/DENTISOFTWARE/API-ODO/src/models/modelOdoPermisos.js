import mongoose from "mongoose";

// Definición del esquema para los permisos
const permisosSchema = mongoose.Schema(
  {
    id_permiso: {
      type: Number,
      required: true, // El campo es obligatorio
      unique: true,   // El id_permiso debe ser único
    },
    rol: {
      type: Number,
      required: true, // El campo es obligatorio
      enum: [1, 2, 3, 4], // Solo permite los valores 1, 2, 3, o 4
      message: "Rol debe ser 1 (ADMIN), 2 (JEFE), 3 (RECEPCIONISTA), o 4 (PACIENTE)",
    },
  },
  {
    timestamps: true, // Para que Mongoose añada createdAt y updatedAt automáticamente
  }
);

// Creación del modelo
const Permiso = mongoose.model("Permiso", permisosSchema);

export default Permiso;
