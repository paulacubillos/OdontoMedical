import mongoose from "mongoose";

const citaSchema = mongoose.Schema({
    numero_documento:{
        type: String,
        required: true,
    },
    hora:{
        type: String,
        required: true,
    },
    fecha:{
        type: String,
        required: true,
    },
    servicio_id:{
        type: String,
        required: true,
    },
    usuario:{
        type: String,
        required: true,
    },
});

export default mongoose.model("Cita", citaSchema);