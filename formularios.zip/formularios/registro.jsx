import React, { useState } from "react";
import bcrypt from "bcryptjs";
import "bootstrap/dist/css/bootstrap.min.css";

const RegisterForm = () => {
  const [formData, setFormData] = useState({
    correo: "",
    clave: "",
    nombre: "",
    apellido: "",
    tipoIdentificacion: "CC",
    numeroIdentificacion: "",
    genero: "Femenino",
    telefono: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Encriptar la clave
    const salt = await bcrypt.genSalt(10);
    const hashedClave = await bcrypt.hash(formData.clave, salt);

    // Preparar datos para enviar a MongoDB
    const dataToSend = { ...formData, clave: hashedClave };

    // Simular envío (reemplaza con tu API real)
    console.log("Datos enviados a la base de datos:", dataToSend);
    alert("Registro enviado exitosamente.");
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Formulario de Registro</h2>
      <form onSubmit={handleSubmit} className="p-4 border rounded bg-light">
        <div className="mb-3">
          <label htmlFor="correo" className="form-label">
            Correo
          </label>
          <input
            type="email"
            className="form-control"
            id="correo"
            name="correo"
            value={formData.correo}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="clave" className="form-label">
            Clave
          </label>
          <input
            type="password"
            className="form-control"
            id="clave"
            name="clave"
            value={formData.clave}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="nombre" className="form-label">
            Nombre
          </label>
          <input
            type="text"
            className="form-control"
            id="nombre"
            name="nombre"
            value={formData.nombre}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="apellido" className="form-label">
            Apellido
          </label>
          <input
            type="text"
            className="form-control"
            id="apellido"
            name="apellido"
            value={formData.apellido}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="tipoIdentificacion" className="form-label">
            Tipo de Identificación
          </label>
          <select
            className="form-select"
            id="tipoIdentificacion"
            name="tipoIdentificacion"
            value={formData.tipoIdentificacion}
            onChange={handleChange}
          >
            <option value="CC">Cédula de Ciudadanía</option>
            <option value="TI">Tarjeta de Identidad</option>
            <option value="PPT">Permiso por Protección Temporal</option>
            <option value="Registro Civil">Registro Civil</option>
          </select>
        </div>
        <div className="mb-3">
          <label htmlFor="numeroIdentificacion" className="form-label">
            Número de Identificación
          </label>
          <input
            type="text"
            className="form-control"
            id="numeroIdentificacion"
            name="numeroIdentificacion"
            value={formData.numeroIdentificacion}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="genero" className="form-label">
            Género
          </label>
          <select
            className="form-select"
            id="genero"
            name="genero"
            value={formData.genero}
            onChange={handleChange}
          >
            <option value="Femenino">Femenino</option>
            <option value="Masculino">Masculino</option>
          </select>
        </div>
        <div className="mb-3">
          <label htmlFor="telefono" className="form-label">
            Teléfono
          </label>
          <input
            type="text"
            className="form-control"
            id="telefono"
            name="telefono"
            value={formData.telefono}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary w-100">
          Registrar
        </button>
      </form>
    </div>
  );
};

export default RegisterForm;
