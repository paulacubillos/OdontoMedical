import swaggerJSDOC from "swagger-jsdoc";
import swaggerUI from "swagger-ui-express";

// Configuración de Swagger
const options = {
    definition: {
        openapi: "3.0.0",
        info: {
            title: "API con conexión a MongoDB",
            version: "1.0.0",
            description: "API conectada a MongoDB y con rutas separadas",
            contact: {
                name: "API Support",
                email: "carol@example.com",
            },
        },
        components: {
            schemas: {
                consultorios: {
                    type: "object",
                    properties: {
                        id_consultorio: {
                            type: "string",
                        },
                        nombre_consultorio: {
                            type: "string",
                        },
                        doctor_acargo: {
                            type: "string",
                        },
                    },
                    required: ["id_consultorio", "nombre_consultorio", "doctor_acargo"],
                    example: {
                        id_consultorio: "4",
                        nombre_consultorio:"Consultorio 4",
                        doctor_acargo:"Yamile Guzman"
                    },
                },
                servicios: {
                    type: "object",
                    properties: {
                        Nombre: {
                            type: "string",
                        },
                        descripcion: {
                            type: "string",
                        },
                        disponible: {
                            type: "string",
                            enum: ["Activo", "Inactivo"],
                        },
                        precio: {
                            type: "number",
                        },
                    },
                    required: ["Nombre", "descripcion", "disponible", "precio"],
                    example: {
                        Nombre: "Ortodoncia",
                        descripcion: "Sistema de arreglo de dientes",
                        disponible: "Activo",
                        precio: 0.0,
                    },
                },
            },
        },
        servers: [
            {
                url: "/api",
                description: "Documentación de consultorios y servicios",
            },
        ],
    },
    apis: ["./src/routes/consultorio.js", "./src/routes/servicio.js"],
};

const swaggerSpec = swaggerJSDOC(options);

const swaggerJSDOCs = (app, port) => {
    app.use("/api-docs", swaggerUI.serve, swaggerUI.setup(swaggerSpec));
    app.get("/api-docs.json", (req, res) => {
        res.setHeader("Content-Type", "application/json");
        res.send(swaggerSpec); // Corregido 'sed' a 'send'
    });
    console.log(
        `La documentación de la API está disponible en http://localhost:${port}/api-docs`
    );
};

export default swaggerJSDOCs;

