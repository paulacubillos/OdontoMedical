import mongoose from "mongoose";

const servSchema = mongoose.Schema({
    Nombre: {
        type: String,
        required: true,
    },
    Descripcion:{
        type: String,
        required: true,
    },
    Disponible:{
        enum: ["Activo", "inactivo"],
    },
    precio:{
        type: Number,
        required: true,
    },
});

export default mongoose.model("Serv", servSchema);