import mongoose from "mongoose";

const consultorioSchema = mongoose.Schema({
    id_consultorio:{
        type: String,
        required: true,
    },
    nombre_consultorio:{
        type: String,
        required: true,
    },
    doctor_acargo:{
        type: String,
        required: true,
    },
});

export default mongoose.model("Consultorio", consultorioSchema);