import Joi from "joi";

//Creamos las validaciones para cada campo
const id = Joi.string()
  .pattern(/^[0-9a-fA-F]{24}$/)
  .required()
  .messages({
    "string.pattern.base":
      "El campo ID debe ser un ObjectId válido de 24 caracteres hexadecimales.",
    "any.required": "El campo ID es requerido.",
  });

  const id_consultorio= Joi.string()
  .min(3)
  .max(50)
  .required()
  .pattern(/^[A-Za-záéíóúÁÉÍÓÚñÑ\s]+$/)
  .messages({
    "string.base": "El id_consultorio debe ser un texto.",
    "string.empty": "El id_consultorio no puede estar vacío.",
    "string.min": "El id_consultorio debe tener al menos 3 caracteres.",
    "string.max": "El id_consultorio no puede exceder los 50 caracteres.",
    "string.pattern.base": "El id_consultorio solo puede contener letras y espacios.",
    "any.required": "El id_consultorio es un campo requerido.",
  });

const nombre_consultorio= Joi.string()
  .min(3)
  .max(50)
  .required()
  .pattern(/^[A-Za-záéíóúÁÉÍÓÚñÑ\s]+$/)
  .messages({
    "string.base": "El nombre_consultorio debe ser un texto.",
    "string.empty": "El nombre_consultorio no puede estar vacío.",
    "string.min": "El nombre_consultorio debe tener al menos 3 caracteres.",
    "string.max": "El nombre_consultorio no puede exceder los 50 caracteres.",
    "string.pattern.base": "El nombre_consultorio solo puede contener letras y espacios.",
    "any.required": "El nombre_consultorio es un campo requerido.",
  });

  const doctor_acargo= Joi.string()
  .min(3)
  .max(50)
  .required()
  .pattern(/^[A-Za-záéíóúÁÉÍÓÚñÑ\s]+$/)
  .messages({
    "string.base": "El doctor_acargo debe ser un texto.",
    "string.empty": "El doctor_acargo no puede estar vacío.",
    "string.min": "El doctor_acargo debe tener al menos 3 caracteres.",
    "string.max": "El doctor_acargo no puede exceder los 50 caracteres.",
    "string.pattern.base": "El doctor_acargo solo puede contener letras y espacios.",
    "any.required": "El doctor_acargo es un campo requerido.",
  });

//Ahora crearemos las validaciones para los métodos de la lógica

const createConsultorioSchema = Joi.object({
  id_consultorio: id_consultorio.required(),
  nombre_consultorio: nombre_consultorio.required(),
  doctor_acargo: doctor_acargo.required(),
});

const updateConsultorioSchema = Joi.object({
  nombre_consultorio: nombre_consultorio.required(),
  doctor_acargo: doctor_acargo.required(),
});

const getConsultorioSchema = Joi.object({
  id: id.required(),
});

const deleteConsultorioSchema = Joi.object({
  id: id.required(),
});

export { createConsultorioSchema,
    getConsultorioSchema,
    updateConsultorioSchema,
    deleteConsultorioSchema};