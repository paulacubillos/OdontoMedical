import express from "express";
import { ActualizarConsultorio, borrarConsultorio, crearconsultorio, llamarConsultorio, llamarConsultorioId } from "../controllers/consultoriocontroller.js";

const router = express.Router();

/**
 * @swagger
 * tags:
 *   - name: Consultorios
 *     description: Endpoints para manejar consultorios
 */
/**
 * @swagger
 * /consultorios:
 *   post:
 *     summary: Crear un nuevo consultorio.
 *     description: Permite crear un nuevo consultorio.
 *     tags:
 *       - Consultorios
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Consultorio'
 *     responses:
 *       201:
 *         description: Consultorio creado exitosamente
 *       400:
 *         description: Error en la información del Consultorio
 */
router.post("/consultorios", crearconsultorio);

/**
 * @swagger
 * /consultorios:
 *   get:
 *     summary: Obtener todos los consultorios
 *     description: Devuelve una lista de todos los consultorios.
 *     tags:
 *       - Consultorios
 *     responses:
 *       200:
 *         description: Lista de consultorios
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Consultorio'
 */
router.get("/consultorios", llamarConsultorio);

/**
 * @swagger
 * /consultorios/{id}:
 *   get:
 *     summary: Obtener un consultorio por ID
 *     description: Devuelve los detalles de un consultorio específico usando su ID.
 *     tags:
 *       - Consultorios
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID del consultorio que se desea obtener
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Detalles del consultorio
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Consultorio'
 *       404:
 *         description: Consultorio no encontrado
 */
router.get("/consultorios/:id", llamarConsultorioId);

/**
 * @swagger
 * /consultorios/{id}:
 *   put:
 *     summary: Actualizar un consultorio existente
 *     description: Permite actualizar los datos de un consultorio existente.
 *     tags:
 *       - Consultorios
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID del consultorio que se desea actualizar
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Consultorio'
 *     responses:
 *       200:
 *         description: Consultorio actualizado exitosamente
 *       400:
 *         description: Error en los datos del consultorio
 *       404:
 *         description: Consultorio no encontrado
 */
router.put("/consultorios/:id", ActualizarConsultorio);

/**
 * @swagger
 * /consultorios/{id}:
 *   delete:
 *     summary: Eliminar un consultorio
 *     description: Permite eliminar un consultorio por su ID.
 *     tags:
 *       - Consultorios
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID del consultorio a eliminar
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Consultorio eliminado exitosamente
 *       404:
 *         description: Consultorio no encontrado
 */
router.delete("/consultorios/:id", borrarConsultorio);


export default router;
