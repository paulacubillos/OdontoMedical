import express from "express";
import { updateServicio, deleteServicio, createServicio, getServicio, getServicioId } from "../controllers/servicioscontroller.js";

const router = express.Router();


/**
 * @swagger
 * tags:
 *   - name: Servicios
 *     description: Endpoints para manejar Servicios
 */
/**
 * @swagger
 * /servicio:
 *   post:
 *     summary: Crear un nuevo servicio
 *     description: Permite crear un nuevo servicio.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Serv'
 *     responses:
 *       201:
 *         description: Servicio creado exitosamente.
 *       400:
 *         description: Error en la información del servicio.
 */
router.post("/servicio", createServicio);

/**
 * @swagger
 * /servicio:
 *   get:
 *     summary: Obtener todos los servicios
 *     description: Devuelve una lista de todos los servicios.
 *     responses:
 *       200:
 *         description: Lista de servicios
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Serv'
 */
router.get("/servicio", getServicio);

/**
 * @swagger
 * /servicio/{id}:
 *   get:
 *     summary: Obtener un servicio por ID
 *     description: Devuelve los detalles de un servicio específico usando su ID.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID del servicio que se desea obtener
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Detalles del servicio
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Serv'
 *       404:
 *         description: Servicio no encontrado
 */
router.get("/servicio/:id", getServicioId);

/**
 * @swagger
 * /servicio/{id}:
 *   put:
 *     summary: Actualizar un servicio existente
 *     description: Permite actualizar los datos de un servicio existente.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID del servicio que se desea actualizar
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Serv'
 *     responses:
 *       200:
 *         description: El servicio ha sido actualizado exitosamente
 *       400:
 *         description: Error en los datos del servicio
 *       404:
 *         description: Servicio no encontrado
 */
router.put("/servicio/:id", updateServicio);

/**
 * @swagger
 * /servicio/{id}:
 *   delete:
 *     summary: Eliminar un servicio
 *     description: Permite eliminar un servicio por su ID.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID del servicio a eliminar
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Servicio eliminado exitosamente
 *       404:
 *         description: Servicio no encontrado
 */
router.delete("/servicio/:id", deleteServicio);

export default router;
