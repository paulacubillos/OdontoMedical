import express from "express";
import cors from "cors";
import servicioRoutes from "./routes/servicio.js";
import router from "./routes/consultorio.js";
import port from "./config/db.js";
import bodyParser from "body-parser";
import swaggerJSDOCs from "../swagger.js";
import dotenv from "dotenv";

dotenv.config();

const app = express();

app.get("/", (req, res)=>{
    res.send("<h1>Bienvenido a mi API web</h1>")
});

app.use(bodyParser.json());
app.use(express.json());
app.use('/api', router);
app.use('/api', servicioRoutes);


var corsOptions = {
     serverApi: {
    version: "1",
    strict: true,
    deprecationErrors: true,
}};
app.use(cors(corsOptions));



app.listen(port, ()=> {
    console.log(`Server listening on port ${port}`);
    swaggerJSDOCs(app,9000);
});

export default cors;