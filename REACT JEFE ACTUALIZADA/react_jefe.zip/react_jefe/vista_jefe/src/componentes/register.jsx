import { useState, useEffect } from "react";
import axios from "axios";

export default function Register({ usuarioSelec }) {
  const [Nombre, setNombre] = useState("");
  const [Hora, setHora] = useState(0);
  const [Procedimiento, setProcedimiento] = useState("");
  const [Consultorio, setConsultorio] = useState("");
  const [Fecha, setFecha] = useState("");
  const [id, setId] = useState("");
  const [error, setError] = useState("");

  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    if (usuarioSelec) {
      setNombre(usuarioSelec.Nombre);
      setHora(usuarioSelec.Hora);
      setProcedimiento(usuarioSelec.Procedimiento);
      setConsultorio(usuarioSelec.Consultorio);
      setFecha(usuarioSelec.Fecha);
      setId(usuarioSelec._id);
      setIsEditing(true);
    }
  }, [usuarioSelec]);

  // funcion para manejar los datos con el boton

  //   const mostrarDatos = () => {
  //     alert(
  //       El nombre registrado fue ${nombre} y su edad ${edad} y el genero ${genero}
  //     );
  //   };

  // Agregar el usuarios
  const agregarUsuario = async (event) => {
    event.preventDefault();
    try {
      const response = await axios.post("http://localhost:5000/api/user", {
        nombre: Nombre,
        Hora: Hora,
        Procedimiento: Procedimiento,
        Consultorio: Consultorio,
        Fecha: Fecha,
      });
      setError("");
      alert("Cita registrado..!!! ");
    } catch (err) {
      if (err.response && err.response.data) {
        setError(err.response.data.message);
        console.log(err.response.data.message);
      } else {
        setError("");
        console.log("Error inesperado ${err.message}");
      }
    }
  };

  const actualizarUsuario = async (event) => {
    event.preventDefault();
    console.error(
      ForntEND = "usuario a modificar ${id} y esta es la edad ${Edad} "
    );

    try {
      const response = await axios.put(
        "http://localhost:5000/api/users/${id} ",
        {
          nombre: Nombre,
          Hora: Hora,
          Procedimiento: Procedimiento,
          Consultorio: Consultorio,
          Fecha: Fecha,
        }
      );
      alert("Usuario modificado correctamente..!!!");
    } catch (error) {
      if (error.response) {
        // Si hay un error de respuesta desde el backend
        alert("Error de validación:", error.response.data);
        setError(error.response.data.message); // Establecer el mensaje de error para mostrarlo en el frontend
      } else {
        // En caso de error no relacionado con la respuesta de la API
        alert("Error inesperado:", error.message);
        setError("Ocurrió un error inesperado.");
      }
    }
  };

  return (
    <>
      <div className="card text-center container">
        <div className="card-header">My Collection </div>
        <div className="card-body card-text">
          <form className="container-fluid">
            <fieldset>
              <legend>
                {isEditing ? "Modificar Usuario" : "Registrar Usuario"}
              </legend>
              <div className="mb-3">
                <label htmlFor="txtNombre" className="form-label">
                  Nombre del Paciente
                </label>
                <input
                  type="text"
                  id="txtNombre"
                  className="form-control"
                  placeholder="Nombre completo"
                  onChange={(event) => {
                    setNombre(event.target.value);
                  }}
                  value={Nombre}
                />
              </div>
              <div className="mb-3">
                <label htmlFor="txtHora" className="form-label">
                  Hora
                </label>
                <input
                  type="time"
                  id="txtHora"
                  className="form-control"
                  placeholder="Hora"
                  onChange={(event) => {
                    setHora(event.target.value);
                  }}
                  value={Hora}
                />
              </div>
              <div className="mb-3">
                <label htmlFor="txtProcedimiento" className="form-label">
                  Procedimiento
                </label>
                {/* <input
                  type="text"
                  id="txtGenero"
                  className="form-control"
                  placeholder="Genero {Masculino/Femenino }"
                  onChange={(event) => {
                    setGenero(event.target.value);
                  }}
                  value={genero}
                /> */}

                <select
                  id="txtProcedimiento"
                  className="form-select"
                  value={Procedimiento} // El valor seleccionado es el del estado
                  aria-label="select para edad"
                  onChange={(event) => {
                    setProcedimiento(event.target.value);
                  }} // Actualiza el estado cuando cambia la selección
                >
                  <option value="">Selecciona un procedimiento</option>
                  <option value="M">Ortodoncia</option>
                  <option value="F">Blanqueamiento Dental</option>
                  <option value="M">Cirugia Molar</option>
                  <option value="F">Rehabilitación Oral</option>
                </select>
              </div>

              <div className="mb-3">
                <label htmlFor="txtConsultorio" className="form-label">
                  Consultorio
                </label>
                {/* <input
                  type="text"
                  id="txtGenero"
                  className="form-control"
                  placeholder="Genero {Masculino/Femenino }"
                  onChange={(event) => {
                    setGenero(event.target.value);
                  }}
                  value={genero}
                /> */}

                <select
                  id="txtConsultorio"
                  className="form-select"
                  value={Consultorio} // El valor seleccionado es el del estado
                  aria-label="select para edad"
                  onChange={(event) => {
                    setConsultorio(event.target.value);
                  }} // Actualiza el estado cuando cambia la selección
                >
                  <option value="">Selecciona un consultorio</option>
                  <option value="M">1</option>
                  <option value="F">2</option>
                </select>
              </div>

              <div className="mb-3">
                <label htmlFor="txtFecha" className="form-label">
                  Fecha
                </label>
                <input
                  type="date"
                  id="txtFecha"
                  className="form-control"
                  placeholder="Fecha"
                  onChange={(event) => {
                    setFecha(event.target.value);
                  }}
                  value={Fecha}
                />
              </div>
            </fieldset>
          </form>
          {error && (
            <div className="alert alert-danger" role="alert">
              {error}
            </div>
          )}
        </div>
        <div className="card-footer text-body-secondary">
          {isEditing ? (
            <button
              type="button"
              className="btn btn-primary"
              onClick={actualizarUsuario}
            >
              Modificar
            </button>
          ) : (
            <button
              type="submit"
              className="btn btn-success"
              onClick={agregarUsuario}
            >
              Guardar datos
            </button>
          )}
        </div>
      </div>
    </>
  );
}