function Bienvenido() {
    return (
        <h1>BIENVENIDO JEFE</h1>
    );
  }
  
  export default Bienvenido;