import { Link } from 'react-router-dom';
import "../assets/css/NavbarPacinente.css";

function NavbarAdmin() {
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light">
      <div className="container-fluid">
        <Link className="navbar-brand" to="/">
          ADMINISTRACION
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link className="nav-link active" to="/admin/usuarios">
                Usuarios
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/admin/servicios">
                Servicios
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/admin/historial">
                Historial
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/admin/doctores">
                Doctores
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/admin/consultorios">
                Consultorios
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/admin/citas">
                Citas
              </Link>
            </li>
          </ul>
        </div>
        <button
          className="btn btn-info ms-3"
          onClick={() => {
            alert('Sesión cerrada');
          }}
          style={{
            backgroundColor: '#a3c9f1',
            borderColor: '#007bff',
            color: '#ffffff',
            fontWeight: 'bold',
          }}
        >
          Cerrar sesión
        </button>
      </div>
    </nav>
  );
}

export default NavbarAdmin;
