import React from 'react';
import { Link } from 'react-router-dom';

const NavbarPaciente = () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light">
      <div className="container-fluid">
        <Link className="navbar-brand" to="/paciente/inicio">
          OdontoMedical
        </Link>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link className="nav-link active" to="/paciente/inicio">
                Inicio
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/paciente/servicios">
                Servicios
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/paciente/nosotros">
                Nosotros
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/paciente/contacto">
                Contacto
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/paciente/agendar">
                Agendar Cita
              </Link>
            </li>
          </ul>
        </div>

        {/* Botón de cerrar sesión */}
        <button
          className="btn btn-info ms-3"
          onClick={() => {
            // LÓGICA PARA CERRAR SESIÓN (aún no implementado)
            alert('Sesión cerrada');
          }}
          style={{
            backgroundColor: "#a3c9f1", 
            borderColor: "#007bff",      
            color: "#ffffff",            
            fontWeight: "bold",          
          }}
        >
          Cerrar sesión
        </button>
      </div>
    </nav>
  );
};

export default NavbarPaciente;

