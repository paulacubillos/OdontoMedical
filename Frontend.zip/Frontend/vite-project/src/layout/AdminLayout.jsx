import React from 'react';
import NavbarAdmin from '../components/NavbarAdmin';

const AdminLayout = ({ children }) => {
  return (
    <>
      <NavbarAdmin />
      <div className="container mt-4">{children}</div>
    </>
  );
};

export default AdminLayout;
