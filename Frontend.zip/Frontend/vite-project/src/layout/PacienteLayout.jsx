import React from 'react';
import NavbarPaciente from '../components/NavbarPaciente';

const PacienteLayout = ({ children }) => {
  return (
    <>
      <NavbarPaciente />
      <div className="container mt-4">{children}</div>
    </>
  );
};

export default PacienteLayout;
