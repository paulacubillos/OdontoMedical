import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import AdminLayout from './layout/AdminLayout.jsx';
import PacienteLayout from './layout/PacienteLayout.jsx';

// Formularios
import InicioSesion from './page/FORMULARIOS/inicioOdoSesion.jsx';
import Register from './page/FORMULARIOS/registerOdo.jsx';

// Páginas del Administrador
import UserTable from './page/ADMIN/TablaUser.jsx';
import TablaServ from './page/ADMIN/TablaServi.jsx';
import TablaHisto from './page/ADMIN/TablaHisto.jsx';
import DoctorasTable from './page/ADMIN/TablaDoc.jsx';
import CitasTable from './page/ADMIN/TablaCitas.jsx';
import ConsultoriosTable from './page/ADMIN/TablaConsultorios.jsx';

// Páginas del Paciente
import AgendarFormulario from './page/PACIENTE/agendarOdoCita.jsx';
import InicioOdo from './page/PACIENTE/inicioOdo.jsx';
import ServiciosOdo from './page/PACIENTE/serviciosOdo.jsx';
import NosotrosOdo from './page/PACIENTE/serviciosOdo.jsx';
import ContactoOdo from './page/PACIENTE/contactoOdo.jsx';


function App() {
  return (
    <Router>
      <Routes>
        {/* Rutas del Administrador */}
        <Route
          path="/admin/*"
          element={
            <AdminLayout>
              <Routes>
                <Route path="usuarios" element={<UserTable />} />
                <Route path="servicios" element={<TablaServ />} />
                <Route path="historial" element={<TablaHisto />} />
                <Route path="doctores" element={<DoctorasTable />} />
                <Route path="citas" element={<CitasTable />} />
                <Route path="consultorios" element={<ConsultoriosTable />} />
              </Routes>
            </AdminLayout>
          }
        />

       {/* Rutas del Paciente */}
        <Route
          path="paciente/*"
          element={
            <PacienteLayout>
              <Routes>
                <Route path="agendar" element={<AgendarFormulario />} />
                <Route path="login" element={<InicioSesion />} />
                <Route path="register" element={<Register />} />
                <Route path="inicio" element={<InicioOdo />} />
                <Route path="servicios" element={< ServiciosOdo />} />
                <Route path='nosotros' element={< NosotrosOdo />} />
                <Route path='contacto' element={< ContactoOdo />} />
                <Route path="" element={<Navigate to="agendar" />} />
              </Routes>
            </PacienteLayout>
          }
        />
        
        {/* Página no encontrada */}
        <Route path="*" element={<h2>Página no encontrada</h2>} />
      </Routes>
    </Router>
  );
}

export default App;



