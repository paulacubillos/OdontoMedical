import { useState, useEffect } from "react";
import axios from "axios";

const UserTable = () => {
    const [users, setUsers] = useState([]);
    const [editingUser, setEditingUser] = useState(null);
    const apiUrl = "http://localhost:5000/api/users"; 

    useEffect(() => {
        fetchUsers();
    }, []);

    const fetchUsers = async () => {
        try {
            const response = await axios.get(apiUrl);
            setUsers(response.data);
        } catch (error) {
            console.error("Error al obtener usuarios:", error);
        }
    };

    const handleEdit = (user) => {
        setEditingUser(user);
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setEditingUser({ ...editingUser, [name]: value });
    };
    

    const handleSave = async () => {
        try {
            const response = await axios.put(`${apiUrl}/${editingUser._id}`, editingUser);
            setUsers(users.map((user) => (user._id === response.data._id ? response.data : user)));
            setEditingUser(null); // Cerrar formulario
        } catch (error) {
            console.error("Error al guardar usuario:", error);
        }
    };

    const handleDelete = async (id) => {
        const confirmDelete = window.confirm(`¿Estás seguro de eliminar el usuario con ID: ${id}?`);
        if (confirmDelete) {
            try {
                await axios.delete(`${apiUrl}/${id}`);
                setUsers(users.filter((user) => user._id !== id));
            } catch (error) {
                console.error("Error al eliminar usuario:", error);
            }
        }
    };

    return (
        <div className="container mt-5">
            <h2 className="mb-4 text-center">Gestión de Usuarios</h2>

            {/* Tabla de usuarios */}
            <table
                className="table table-hover"
                style={{
                    backgroundColor: "#f8f9fa",
                    borderRadius: "10px",
                    overflow: "hidden",
                    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
                }}
            >
                <thead
                    className="table-dark"
                    style={{
                        backgroundColor: "#343a40",
                        color: "#ffffff",
                        borderRadius: "10px 10px 0 0",
                    }}
                >
                    <tr>
                        <th>Id</th>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Doc. Identificación</th>
                        <th>Correo</th>
                        <th>Rol</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    {users.map((user) => (
                        <tr key={user._id}>
                            <td>{user._id}</td>
                            <td>{user.nombre}</td>
                            <td>{user.apellido}</td>
                            <td>{user.Doc_identificacion}</td> 
                            <td>{user.correo}</td>
                            <td>{user.Id_rol }</td>
                            <td>
                                <button
                                    className="btn btn-warning btn-sm me-2"
                                    onClick={() => handleEdit(user)}
                                >
                                    Editar
                                </button>
                                <button
                                    className="btn btn-danger btn-sm"
                                    onClick={() => handleDelete(user._id)}
                                >
                                    Borrar
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

     
            {editingUser && (
                <div
                    className="p-4 mt-4"
                    style={{
                        backgroundColor: "#f8f9fa",
                        borderRadius: "10px",
                        boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
                    }}
                >
                    <h4>Editar Usuario</h4>
                    <form>
                        <div className="mb-3">
                            <label className="form-label">Nombre</label>
                            <input
                                type="text"
                                className="form-control"
                                name="nombre"
                                value={editingUser.nombre}
                                onChange={handleChange}
                            />
                        </div>
                        <div className="mb-3">
                            <label className="form-label">Apellido</label>
                            <input
                                type="text"
                                className="form-control"
                                name="apellido"
                                value={editingUser.apellido}
                                onChange={handleChange}
                            />
                        </div>
                        <div className="mb-3">
                            <label className="form-label">Doc. Identificación</label>
                            <input
                                type="text"
                                className="form-control"
                                name="Doc_identificacion" 
                                value={editingUser.Doc_identificacion}
                                onChange={handleChange}
                            />
                        </div>
                        <div className="mb-3">
                            <label className="form-label">Correo</label>
                            <input
                                type="email"
                                className="form-control"
                                name="correo"
                                value={editingUser.correo}
                                onChange={handleChange}
                            />
                        </div>
                        <div className="mb-3">
                            <label className="form-label">Rol</label>
                            <select
                                className="form-select"
                                name="Id_rol"
                                value={editingUser.rol}
                                onChange={handleChange}
                            >
                                <option value="1">ADMIN</option>
                                <option value="2">JEFE</option>
                                <option value="3">RECEPCIONISTA</option>
                                <option value="4">PACIENTE</option>
                            </select>
                        </div>
                        <button type="button" className="btn btn-success me-2" onClick={handleSave}>
                            Guardar
                        </button>
                        <button
                            type="button"
                            className="btn btn-secondary"
                            onClick={() => setEditingUser(null)}
                        >
                            Cancelar
                        </button>
                    </form>
                </div>
            )}
        </div>
    );
};

export default UserTable;


