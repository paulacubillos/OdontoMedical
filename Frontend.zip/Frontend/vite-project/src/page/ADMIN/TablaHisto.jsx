import React, { useEffect, useState } from 'react';
import axios from 'axios';

const TablaHisto = () => {
    const [histories, setHistories] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:5000/api/historial')
            .then(response => {
                setHistories(response.data);
            })
            .catch(error => {
                console.error('Hubo un error al obtener los historiales:', error);
            });
    }, []);

    return (
        <div className="container mt-5">
            <h2 className="mb-4 text-center">Historiales Clínicos</h2>

            <table
                className="table table-hover"
                style={{
                    backgroundColor: "#f8f9fa",
                    borderRadius: "10px",
                    overflow: "hidden",
                    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
                }}
            >
                <thead
                    className="table-dark"
                    style={{
                        backgroundColor: "#343a40",
                        color: "#ffffff",
                        borderRadius: "10px 10px 0 0",
                    }}
                >
                    <tr>
                        <th>Id</th>
                        <th>Nombres</th>
                        <th>Apellidos</th>
                        <th>Documento de Identificación</th>
                        <th>Descripción del Tratamiento</th>
                        <th>Fecha del Tratamiento</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    {histories.map((history) => (
                        <tr key={history._id}>
                            <td>{history._id}</td>
                            <td>{history.Id_usuario?.Nombres}</td> 
                            <td>{history.Id_usuario?.Apellidos}</td>
                            <td>{history.Id_usuario?.Doc_identificacion}</td>
                            <td>{history.Descripcion_tratamiento}</td>
                            <td>{new Date(history.Fecha_tratamiento).toLocaleDateString()}</td>
                            <td>
                                <button
                                    className="btn btn-warning btn-sm me-2"
                                    style={{
                                        borderRadius: "20px",
                                        fontWeight: "bold",
                                    }}
                                    onClick={() =>
                                        alert(`Editar historial con ID: ${history._id}`)
                                    }
                                >
                                    Editar
                                </button>
                                <button
                                    className="btn btn-danger btn-sm"
                                    style={{
                                        borderRadius: "20px",
                                        fontWeight: "bold",
                                    }}
                                    onClick={() =>
                                        alert(`Eliminar historial con ID: ${history._id}`)
                                    }
                                >
                                    Borrar
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default TablaHisto;

