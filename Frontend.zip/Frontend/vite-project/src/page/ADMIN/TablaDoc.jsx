import React, { useState, useEffect } from "react";
import axios from "axios";

const DoctorasTable = () => {
    const [doctoras, setDoctoras] = useState([]);
    const [editingDoctora, setEditingDoctora] = useState(null);
    const [editData, setEditData] = useState({
        Nombres: '',
        Apellidos: '',
        Cargo: '',
        Id_consultorio: ''
    });

    useEffect(() => {
        axios.get("http://localhost:5000/api/doctora")
            .then((response) => {
                setDoctoras(response.data);
            })
            .catch((error) => {
                console.error("Hubo un error al obtener las doctoras:", error);
            });
    }, []);
    const handleEdit = (doctora) => {
        setEditingDoctora(doctora.id);
        setEditData({
            Nombres: doctora.Nombres + " ",
            Apellidos: doctora.Apellidos + " ",
            Cargo: doctora.Cargo,
            Id_consultorio: doctora.id_consultorio
        });
    };
    const saveEdit = () => {
        axios.put(`http://localhost:5000/api/doctora/${editingDoctora}`, editData)
            .then((response) => {
                const updatedDoctoras = doctoras.map((doctora) =>
                    doctora.id === editingDoctora ? response.data : doctora
                );
                setDoctoras(updatedDoctoras);
                setEditingDoctora(null); 
            })
            .catch((error) => {
                console.error("Error al guardar la doctora:", error);
            });
    };
    const cancelEdit = () => {
        setEditingDoctora(null); 
    };
    const handleDelete = (id) => {
        axios.delete(`http://localhost:5000/api/doctora/${id}`)
            .then(() => {
                const updatedDoctoras = doctoras.filter((doctora) => doctora.id !== id);
                setDoctoras(updatedDoctoras);
            })
            .catch((error) => {
                console.error("Error al eliminar la doctora:", error);
            });
    };

    return (
        <div className="container mt-5">
            <h2 className="mb-4 text-center">Gestión de Doctoras</h2>
            <table
                className="table table-hover"
                style={{
                    backgroundColor: "#f8f9fa",
                    borderRadius: "10px",
                    overflow: "hidden",
                    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
                }}
            >
                <thead
                    className="table-dark"
                    style={{
                        backgroundColor: "#343a40",
                        color: "#ffffff",
                        borderRadius: "10px 10px 0 0",
                    }}
                >
                    <tr>
                        <th>ID</th>
                        <th>Nombres</th>
                        <th>Apellidos</th>
                        <th>Cargo</th>
                        <th>ID Consultorio</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    {doctoras.map((doctora) => (
                        <tr key={doctora.id}>
                            <td>{doctora.id}</td>
                            <td>{doctora.Nombres}</td>
                            <td>{doctora.Apellidos}</td>
                            <td>{doctora.Cargo}</td>
                            <td>{doctora.id_consultorio}</td>
                            <td>
                                {editingDoctora === doctora.id ? (
                                    <div>
                                        <input
                                            type="text"
                                            value={editData.Nombres}
                                            onChange={(e) => setEditData({ ...editData, Nombres: e.target.value })}
                                            className="form-control mb-2"
                                            placeholder="Nombres"
                                        />
                                        <input
                                            type="text"
                                            value={editData.Apellidos}
                                            onChange={(e) => setEditData({ ...editData, Apellidos: e.target.value })}
                                            className="form-control mb-2"
                                            placeholder="Apellidos"
                                        />
                                        <input
                                            type="text"
                                            value={editData.Cargo}
                                            onChange={(e) => setEditData({ ...editData, Cargo: e.target.value })}
                                            className="form-control mb-2"
                                            placeholder="Cargo"
                                        />
                                        <input
                                            type="text"
                                            value={editData.Id_consultorio}
                                            onChange={(e) => setEditData({ ...editData, Id_consultorio: e.target.value })}
                                            className="form-control mb-2"
                                            placeholder="ID Consultorio"
                                        />
                                        <button
                                            className="btn btn-success btn-sm me-2"
                                            style={{
                                                borderRadius: "20px",
                                                fontWeight: "bold",
                                            }}
                                            onClick={saveEdit}
                                        >
                                            Guardar
                                        </button>
                                        <button
                                            className="btn btn-secondary btn-sm"
                                            style={{
                                                borderRadius: "20px",
                                                fontWeight: "bold",
                                            }}
                                            onClick={cancelEdit}
                                        >
                                            Cancelar
                                        </button>
                                    </div>
                                ) : (
                                    <>
                                        <button
                                            className="btn btn-warning btn-sm me-2"
                                            style={{
                                                borderRadius: "20px",
                                                fontWeight: "bold",
                                            }}
                                            onClick={() => handleEdit(doctora)}
                                        >
                                            Editar
                                        </button>
                                        <button
                                            className="btn btn-danger btn-sm"
                                            style={{
                                                borderRadius: "20px",
                                                fontWeight: "bold",
                                            }}
                                            onClick={() => handleDelete(doctora.id)}
                                        >
                                            Borrar
                                        </button>
                                    </>
                                )}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default DoctorasTable;
