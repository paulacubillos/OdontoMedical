import React, { useEffect, useState } from 'react';
import axios from 'axios';

const CitasTable = () => {
  const [citas, setCitas] = useState([]);

  const fetchCitas = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/citas');
      setCitas(response.data);
    } catch (error) {
      console.error('Error al obtener citas:', error);
    }
  };

  const deleteCita = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/citas/${id}`);
      setCitas(citas.filter((cita) => cita._id !== id)); 
      alert('Cita eliminada con éxito');
    } catch (error) {
      console.error('Error al eliminar cita:', error);
      alert('Error al eliminar la cita');
    }
  };

  useEffect(() => {
    fetchCitas();
  }, []);

  return (
    <div className="container mt-5">
      <h2 className="mb-4 text-center">Gestión de Citas</h2>
      <table
        className="table table-hover"
        style={{
          backgroundColor: '#f8f9fa',
          borderRadius: '10px',
          overflow: 'hidden',
          boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
        }}
      >
        <thead
          className="table-dark"
          style={{
            backgroundColor: '#343a40',
            color: '#ffffff',
            borderRadius: '10px 10px 0 0',
          }}
        >
          <tr>
            <th>ID</th>
            <th>Número de Documento</th>
            <th>Hora</th>
            <th>Fecha</th>
            <th>Usuario</th>
            <th>Servicio</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {citas.map((cita) => (
            <tr key={cita._id}>
              <td>{cita._id}</td>
              <td>{cita.Numero_documento}</td>
              <td>{cita.Hora}</td>
              <td>{cita.Fecha}</td>
              <td>{cita.Usuario}</td>
              <td>{cita.Servicio_id}</td>
              <td>
                <button
                  className="btn btn-warning btn-sm me-2"
                  style={{
                    borderRadius: '20px',
                    fontWeight: 'bold',
                  }}
                  onClick={() => alert(`Editar cita con ID: ${cita._id}`)}
                >
                  Editar
                </button>
                <button
                  className="btn btn-danger btn-sm"
                  style={{
                    borderRadius: '20px',
                    fontWeight: 'bold',
                  }}
                  onClick={() => deleteCita(cita._id)}
                >
                  Borrar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CitasTable;
