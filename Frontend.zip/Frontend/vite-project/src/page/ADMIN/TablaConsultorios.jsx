import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ConsultoriosTable = () => {
    const [consultorios, setConsultorios] = useState([]);
    const [editingConsultorio, setEditingConsultorio] = useState(null); // Para saber qué consultorio estamos editando
    const [editData, setEditData] = useState({
        Nombre_consultorio: '',
        doctor_acargo: ''
    });

    useEffect(() => {
        // Obtener consultorios de la API
        axios.get('http://localhost:5000/api/consultorios')
            .then((response) => {
                setConsultorios(response.data);
            })
            .catch((error) => {
                console.error('Hubo un error al obtener los consultorios:', error);
            });
    }, []);

    // Función para editar un consultorio
    const handleEdit = (consultorio) => {
        setEditingConsultorio(consultorio._id); // Establecer el ID del consultorio que estamos editando
        setEditData({
            Nombre_consultorio: consultorio.Nombre_consultorio,
            doctor_acargo: consultorio.doctor_acargo,
        });
    };

    // Función para guardar los cambios después de editar
    const saveEdit = () => {
        axios.put(`http://localhost:5000/api/consultorios/${editingConsultorio}`, editData)
            .then((response) => {
                const updatedConsultorios = consultorios.map((consultorio) =>
                    consultorio._id === editingConsultorio ? response.data : consultorio
                );
                setConsultorios(updatedConsultorios);
                setEditingConsultorio(null); // Restablecer el estado de edición
            })
            .catch((error) => {
                console.error('Error al guardar el consultorio:', error);
            });
    };

    // Función para cancelar la edición
    const cancelEdit = () => {
        setEditingConsultorio(null); // Restablecer el estado de edición
    };

    // Función para eliminar un consultorio
    const handleDelete = (id) => {
        axios.delete(`http://localhost:5000/api/consultorios/${id}`)
            .then(() => {
                const updatedConsultorios = consultorios.filter((consultorio) => consultorio._id !== id);
                setConsultorios(updatedConsultorios);
            })
            .catch((error) => {
                console.error('Error al eliminar el consultorio:', error);
            });
    };

    return (
        <div className="container mt-5">
            <h2 className="mb-4 text-center">Gestión de Consultorios</h2>
            <table
                className="table table-hover"
                style={{
                    backgroundColor: "#f8f9fa",
                    borderRadius: "10px",
                    overflow: "hidden",
                    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
                }}
            >
                <thead
                    className="table-dark"
                    style={{
                        backgroundColor: "#343a40",
                        color: "#ffffff",
                        borderRadius: "10px 10px 0 0",
                    }}
                >
                    <tr>
                        <th>ID</th>
                        <th>Nombre del Consultorio</th>
                        <th>Doctor(a) a Cargo</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    {consultorios.map((consultorio) => (
                        <tr key={consultorio._id}>
                            <td>{consultorio._id}</td>
                            <td>{consultorio.Nombre_consultorio}</td>
                            <td>{consultorio.doctor_acargo}</td>
                            <td>
                                {editingConsultorio === consultorio._id ? (
                                    // Mostrar el formulario de edición cuando estamos editando este consultorio
                                    <div>
                                        <input
                                            type="text"
                                            value={editData.Nombre_consultorio}
                                            onChange={(e) => setEditData({ ...editData, Nombre_consultorio: e.target.value })}
                                            className="form-control mb-2"
                                            placeholder="Nombre del Consultorio"
                                        />
                                        <input
                                            type="text"
                                            value={editData.doctor_acargo}
                                            onChange={(e) => setEditData({ ...editData, doctor_acargo: e.target.value })}
                                            className="form-control mb-2"
                                            placeholder="Doctor(a) a Cargo"
                                        />
                                        <button
                                            className="btn btn-success btn-sm me-2"
                                            style={{
                                                borderRadius: "20px",
                                                fontWeight: "bold",
                                            }}
                                            onClick={saveEdit}
                                        >
                                            Guardar
                                        </button>
                                        <button
                                            className="btn btn-secondary btn-sm"
                                            style={{
                                                borderRadius: "20px",
                                                fontWeight: "bold",
                                            }}
                                            onClick={cancelEdit}
                                        >
                                            Cancelar
                                        </button>
                                    </div>
                                ) : (
                                    <>
                                        <button
                                            className="btn btn-warning btn-sm me-2"
                                            style={{
                                                borderRadius: "20px",
                                                fontWeight: "bold",
                                            }}
                                            onClick={() => handleEdit(consultorio)}
                                        >
                                            Editar
                                        </button>
                                        <button
                                            className="btn btn-danger btn-sm"
                                            style={{
                                                borderRadius: "20px",
                                                fontWeight: "bold",
                                            }}
                                            onClick={() => handleDelete(consultorio._id)}
                                        >
                                            Borrar
                                        </button>
                                    </>
                                )}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ConsultoriosTable;

