import { Link } from 'react-router-dom';

function Navbar() {
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light">
      <div className="container-fluid">
        <Link className="navbar-brand" to="/">
          ADMINISTRACION
        </Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link className="nav-link active" aria-current="page" to="/usuarios">Usuarios</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/servicios">Servicios</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/historial">Historial</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/doctores">Doctores</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/citas">Citas</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/consultorios">Consultorios</Link>
            </li>
          </ul>
        </div>
        {/* Botón de cerrar sesión */}
        <button 
          className="btn btn-info ms-3" 
          onClick={() => { 
            //LOGICA DE CERRAR SESIOJ
            alert("Sesión cerrada");
          }}
          style={{
            backgroundColor: "#a3c9f1",  
            borderColor: "#007bff",      
            color: "#ffffff",            
            fontWeight: "bold"
          }}
        >
          Cerrar sesión
        </button>
      </div>
    </nav>
  );
}

export default Navbar;

