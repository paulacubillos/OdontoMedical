import React, { useEffect, useState } from 'react';
import axios from 'axios';

const TablaServ = () => {
    const [services, setServices] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:5000/api/servicio')
            .then(response => setServices(response.data))
            .catch(error => console.error('Error al obtener los servicios:', error));
    }, []);

    const handleEdit = (_id) => {
        const serviceToEdit = services.find(service => service.id === _id);
        if (serviceToEdit) {
            alert(`Editar servicio con ID: ${_id}\nNombre: ${serviceToEdit.nombre}`);
        }
    };

    const handleDelete = (_id) => {
        axios.delete(`http://localhost:5000/api/servicio/${_id}`)
            .then(() => {
                setServices(services.filter(service => service.id !== _id));  
            })
            .catch(error => {
                console.error('Error al eliminar el servicio:', error);
            });
    };

    return (
        <div className="container mt-5">
            <h2 className="mb-4 text-center">Gestión de Servicios</h2>
            <table
                className="table table-hover"
                style={{
                    backgroundColor: "#f8f9fa",
                    borderRadius: "10px",
                    overflow: "hidden",
                    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
                }}
            >
                <thead
                    className="table-dark"
                    style={{
                        backgroundColor: "#343a40",
                        color: "#ffffff",
                        borderRadius: "10px 10px 0 0",
                    }}
                >
                    <tr>
                        <th>Id</th>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Disponible</th>
                        <th>Precio</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    {services.map((service) => (
                        <tr key={service.id}>
                            <td>{service.id}</td>
                            <td>{service.Nombre}</td>
                            <td>{service.Descripcion}</td>
                            <td>
                                <span
                                    className={`badge ${
                                        service.Disponible === "Activo"
                                            ? "bg-success"
                                            : "bg-danger"
                                    }`}
                                >
                                    {service.Disponible}
                                </span>
                            </td>
                            <td>{service.Precio}</td>
                            <td>
                                <button
                                    className="btn btn-warning btn-sm me-2"
                                    style={{
                                        borderRadius: "20px",
                                        fontWeight: "bold",
                                    }}
                                    onClick={() => handleEdit(service._id)}
                                >
                                    Editar
                                </button>
                                <button
                                    className="btn btn-danger btn-sm"
                                    style={{
                                        borderRadius: "20px",
                                        fontWeight: "bold",
                                    }}
                                    onClick={() => handleDelete(service._id)}
                                >
                                    Borrar
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default TablaServ;
