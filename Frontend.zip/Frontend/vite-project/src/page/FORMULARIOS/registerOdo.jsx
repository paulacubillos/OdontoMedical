import React, { useState } from "react";
import bcrypt from "bcryptjs";
import "bootstrap/dist/css/bootstrap.min.css";

const Register = ({ addUser }) => {
  const [formData, setFormData] = useState({
    Correo: "",
    Clave: "",
    Nombre: "",
    Apellido: "",
    Tipo_Doc: "CC",
    Doc_identificacion: "",
    Genero: "Femenino",
    Telefono: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const isValidForm = () => {
    const { Correo, Clave, Nombre, Apellido, Doc_identificacion, Telefono } = formData;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const telefonoRegex = /^[0-9]{10}$/;
    return (
      emailRegex.test(Correo) &&
      Clave.length >= 6 &&
      telefonoRegex.test(Telefono) &&
      !isNaN(Doc_identificacion) &&
      Doc_identificacion.trim() !== "" &&
      Nombre.trim() !== "" &&
      Apellido.trim() !== ""
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!isValidForm()) {
      alert("Por favor revisa los datos ingresados.");
      return;
    }
    try {
      const salt = bcrypt.genSaltSync(10);
      const hashedPassword = bcrypt.hashSync(formData.Clave, salt);

      const response = await fetch("http://localhost:5000/api/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...formData, 
          Clave: hashedPassword,  
        }),
      });

      if (response.ok) {
        const data = await response.json();  
        alert("Usuario registrado exitosamente");

        setFormData({
          Correo: "",
          Clave: "",
          Nombre: "",
          Apellido: "",
          Tipo_Doc: "CC",
          Doc_identificacion: "",
          Genero: "Femenino",
          Telefono: "",
        });
      } else {
        const errorData = await response.json();
        alert(`Error: ${errorData.message}`);
      }
    } catch (error) {
      console.error("Error al registrar al usuario:", error);
      alert("Ocurrió un error. Inténtalo nuevamente.");
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Registro de Usuario</h2>
      <form onSubmit={handleSubmit} className="card p-4 shadow">
        <div className="mb-3">
          <label htmlFor="Correo" className="form-label">Correo</label>
          <input
            type="email"
            id="Correo"
            name="Correo"
            className="form-control"
            value={formData.Correo}
            onChange={handleChange}
            placeholder="Ingresa tu correo"
            required
          />
        </div>

        <div className="mb-3">
          <label htmlFor="Clave" className="form-label">Clave</label>
          <input
            type="password"
            id="Clave"
            name="Clave"
            className="form-control"
            value={formData.Clave}
            onChange={handleChange}
            placeholder="Ingresa tu clave (mínimo 6 caracteres)"
            required
          />
        </div>

        <div className="mb-3">
          <label htmlFor="Nombre" className="form-label">Nombre</label>
          <input
            type="text"
            id="Nombre"
            name="Nombre"
            className="form-control"
            value={formData.Nombre}
            onChange={handleChange}
            placeholder="Ingresa tu nombre"
            required
          />
        </div>

        <div className="mb-3">
          <label htmlFor="Apellido" className="form-label">Apellido</label>
          <input
            type="text"
            id="Apellido"
            name="Apellido"
            className="form-control"
            value={formData.Apellido}
            onChange={handleChange}
            placeholder="Ingresa tu apellido"
            required
          />
        </div>

        <div className="mb-3">
          <label htmlFor="Tipo_Doc" className="form-label">Tipo de Identificación</label>
          <select
            id="Tipo_Doc"
            name="Tipo_Doc"
            className="form-select"
            value={formData.Tipo_Doc}
            onChange={handleChange}
            required
          >
            <option value="CC">Cédula de Ciudadanía</option>
            <option value="TI">Tarjeta de Identidad</option>
            <option value="PPT">Permiso por Protección Temporal</option>
            <option value="Registro Civil">Registro Civil</option>
          </select>
        </div>

        <div className="mb-3">
          <label htmlFor="Doc_identificacion" className="form-label">Número de Identificación</label>
          <input
            type="text"
            id="Doc_identificacion"
            name="Doc_identificacion"
            className="form-control"
            value={formData.Doc_identificacion}
            onChange={handleChange}
            placeholder="Ingresa tu número de identificación"
            required
          />
        </div>

        <div className="mb-3">
          <label htmlFor="Genero" className="form-label">Género</label>
          <select
            id="Genero"
            name="Genero"
            className="form-select"
            value={formData.Genero}
            onChange={handleChange}
            required
          >
            <option value="Femenino">Femenino</option>
            <option value="Masculino">Masculino</option>
          </select>
        </div>

        <div className="mb-3">
          <label htmlFor="Telefono" className="form-label">Teléfono</label>
          <input
            type="tel"
            id="Telefono"
            name="Telefono"
            className="form-control"
            value={formData.Telefono}
            onChange={handleChange}
            placeholder="Ingresa tu teléfono (10 dígitos)"
            required
          />
        </div>

        <button type="submit" className="btn btn-primary w-100">
          Registrar
        </button>
      </form>
    </div>
  );
};

export default Register;
