import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../../assets/css/inicioOdoSesion.css";

export default function InicioSesion() {
  const [Correo, setCorreo] = useState("");
  const [Clave, setClave] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate(); // Hook para redirección

  const styles = {
    loginContainer: {
      maxWidth: "400px",
      margin: "0 auto",
      padding: "20px",
      border: "1px solid #ddd",
      borderRadius: "8px",
      boxShadow: "0 0 10px rgba(0, 0, 0, 0.1)",
    },
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("http://localhost:5000/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ Correo: Correo, Clave }),
      });

      const data = await response.json();

      if (response.ok) {
        setError("");
        navigate("/citas");
      } else {
        setError(data.message || "Error al iniciar sesión");
      }
    } catch (err) {
      setError("Error en la conexión con el servidor");
    }
  };

  return (
    <div style={styles.loginContainer} className="mt-5">
      <h2 className="text-center mb-4">Iniciar Sesión</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="correo" className="form-label">
            Correo electrónico
          </label>
          <input
            type="email"
            className="form-control"
            id="correo"
            name="correo"
            value={Correo}
            onChange={(e) => setCorreo(e.target.value)}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="password" className="form-label">
            Contraseña
          </label>
          <input
            type="password"
            className="form-control"
            id="password"
            name="password"
            value={Clave}
            onChange={(e) => setClave(e.target.value)}
            required
          />
        </div>
        {error && <p className="text-danger text-center">{error}</p>}
        <button type="submit" className="btn btn-primary w-100">
          Iniciar Sesión
        </button>
        <p className="text-center mt-3">
          ¿No tienes cuenta? <Link to="/">Regístrate</Link>
        </p>
      </form>
    </div>
  );
}
