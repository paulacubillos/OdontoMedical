import React from 'react';
import { Link } from 'react-router-dom';
import "../../assets/css/nosotrosOdo.css";
const NosotrosOdo = () => {
  return (
    <>
    <div>
      <div id="carouselExampleSlidesOnly" className="carousel slide" data-bs-ride="carousel">
        <div className="carousel-inner">
          <div className="carousel-item active">
            <img src="../../assets/img/carrusel_1.png" className="d-block w-100" alt="..." />
          </div>
          <div className="carousel-item">
            <img src="../../assets/img/carrusel_2.png" className="d-block w-100" alt="..." />
          </div>
          <div className="carousel-item">
            <img src="../../assets/img/carrusel_3.png" className="d-block w-100" alt="..." />
          </div>
        </div>
      </div>
      <div className="d-flex justify-content-center mt-4">
      <Card style={{ width: '40rem' }} className="shadow-lg rounded">
        <Card.Body>
          <Card.Title className="text-center">Acerca de Nosotros</Card.Title>
          <Card.Text>
            Somos una clínica comprometida con tu salud y bienestar dental.
            Contamos con un equipo profesional dedicado a brindar servicios de calidad.
          </Card.Text>
          <Button variant="primary" className="btn">Leer más</Button>
        </Card.Body>
      </Card>
    </div>
    <div className="d-flex justify-content-center mt-4">
      {/* Tarjeta con tratamiento */}
      <Card style={{ width: '40rem' }} className="shadow-lg rounded">
        <Card.Body>
          <Card.Title className="text-center">Tratamientos Dentales</Card.Title>
          <Card.Text>
            Ofrecemos una amplia gama de tratamientos dentales: limpieza, ortodoncia, implantología, y más.
          </Card.Text>
          <Button variant="primary" block>
            Ver más detalles
          </Button>
        </Card.Body>
      </Card>
    </div>

      <div className="container">
        <div className="row">
          <div className="col-sm-6 mb-3 mb-sm-0">
            <div className="card">
              <div className="card-body">
                <h5 className="card-title">Misión</h5>
                <p className="card-text">
                  En Odontomedical, nos dedicamos a ofrecer una atención odontológica integral,
                  basada en las necesidades únicas de cada paciente y en los más recientes avances científicos.
                </p>
              </div>
            </div>
          </div>
          <div className="col-sm-6">
            <div className="card">
              <div className="card-body">
                <h5 className="card-title">Visión</h5>
                <p className="card-text">
                  Ser líder en odontología, ofreciendo servicios de alta calidad y
                  atención personalizada respaldada por tecnología innovadora,
                  buscando destacar como un centro de excelencia reconocido mundialmente por nuestro compromiso
                  con la salud bucal y el bienestar de los pacientes.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="d-flex justify-content-center mt-4">
        <Card style={{ width: '40rem' }} className="shadow-lg rounded">
          <Card.Body>
            <Card.Title className="text-center">Misión</Card.Title>
            <Card.Text>
            En Odontomedical, nos dedicamos a ofrecer una atención odontológica integral, basada en las necesidades únicas de cada paciente y en los más recientes avances científicos.
            </Card.Text>
          </Card.Body>
        </Card>
        <div className="d-flex justify-content-center mt-4">
        <Card style={{ width: '40rem' }} className="shadow-lg rounded">
          <Card.Body>
            <Card.Title className="text-center">Visión</Card.Title>
            <Card.Text>
            Ser líder en odontología, ofreciendo servicios de alta calidad y 
            atención personalizada respaldada por tecnología innovadora, buscando destacar como un centro de excelencia reconocido mundialmente por nuestro compromiso con la salud bucal y el bienestar de los pacientes.
            </Card.Text>
          </Card.Body>
        </Card>
      </div>
      </div>

      <footer>
        <div className="footer-container">
          <div className="footer-section">
            <h4>Servicios :</h4>
            <ul>
              <li><Link to="#">Blanqueamiento dental</Link></li>
              <li><Link to="#">Ortodoncia</Link></li>
              <li><Link to="#">Rehabilitación Oral</Link></li>
              <li><Link to="#">Implantes dentales</Link></li>
            </ul>
          </div>
          <div className="footer-section">
            <h4>Sobre OdontoMedical:</h4>
            <ul>
              <li><Link to="/nosotros_odo">Acerca de nosotros</Link></li>
            </ul>
          </div>
          <div className="footer-section">
            <h4>Síguenos en nuestras redes</h4>
            <div className="social-media">
              <a href="#"><img src="../../assets/img/whatsapp.svg" alt="WhatsApp" /></a>
            </div>
            <p>Dirección: Calle 70 sur #78-25</p>
            <p>Teléfono: 7566656</p>
            <p>Correo: odontomedical@gmail.com</p>
          </div>
        </div>
      </footer>
    </div>
      <div>
      <section className="contact-section">
        <h2>Contactenos</h2>
        <div className="contact-container">
          <div className="contact-box">
            <img src="../../assets/img/whatsapp.svg" alt="WhatsApp" width="50" />
            <p>+57 320 0225854</p>
            <p>(601) 7452 155</p>
          </div>
          <div className="contact-box">
            <img src="../../assets/img/email.svg" alt="Email" width="50" />
            <p>@OdontoMedical_Clinica</p>
            <p>odontomedical@gmail.com</p>
          </div>
        </div>
        <iframe 
          src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1876.695185677086!2d-74.11719985174699!3d4.6690079622209755!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f9b78be3bf4fd%3A0x65b5e6a92f443720!2zQ3JhLiA3NSAjMjVjMjQsIEZvbnRpYsOzbiwgQm9nb3TDoQ!5e0!3m2!1ses-419!2sco!4v1725127166861!5m2!1ses-419!2sco" 
          width="800" 
          height="600" 
          style={{border: 0}} 
          allowFullScreen="" 
          loading="lazy" 
          referrerPolicy="no-referrer-when-downgrade" 
        />
      </section>

      <footer>
        <div className="footer-container">
          <div className="footer-section">
            <h4>Servicios :</h4>
            <ul>
              <li><Link to="#">Blanqueamiento dental</Link></li>
              <li><Link to="#">Ortodoncia</Link></li>
              <li><Link to="#">Rehabilitación Oral</Link></li>
              <li><Link to="#">Implantes dentales</Link></li>
            </ul>
          </div>
          <div className="footer-section">
            <h4>Sobre OdontoMedical:</h4>
            <ul>
              <li><Link to="/nosotros_odo">Acerca de nosotros</Link></li>
            </ul>
          </div>
          <div className="footer-section">
            <h4>Síguenos en nuestras redes</h4>
            <div className="social-media">
              <img src="../../assets/img/email.svg" alt="Email" width="50" />
              <a href="#"><img src="../../assets/img/whatsapp.svg" alt="WhatsApp" /></a>
            </div>
            <p>Dirección: Calle 70 sur #78-25</p>
            <p>Teléfono: 7566656</p>
            <p>Correo: odontomedical@gmail.com</p>
          </div>
        </div>
      </footer>
    </div>
    </>
  );
};

export default NosotrosOdo;
