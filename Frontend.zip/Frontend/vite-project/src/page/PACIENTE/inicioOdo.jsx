import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import "../../assets/css/InicioOdo.css";

const InicioOdo = () => {
  return (
    <>
    <div className="hero-section">
    <img
      src="https://clinicavargasridao.com/wp-content/uploads/2024/10/ortodoncia-en-ninos-entre-los-6-y-7-anos.webp"
      alt="Hero"
      className="hero-image"
    />
    <div className="hero-text">
    <h1>DRA. YAMILE GUZMAN</h1>
        <p>Especialista en Periodoncia e Implantología
   Más de 12 Años de experiencia en el área
OdontoMedical, Innovación y cuidado para cada sonrisa</p>
    </div>
    <div className="text-center my-4"> {/* Clase para centrar y agregar espacio */}
      <button className="btn btn-primary btn-lg">¡Haz tu valoración aquí!</button> {/* Estilo de Bootstrap */}
    </div>
  </div>
    <div>
      <div className="container">
        <img src="../../assets/img/cont-1.jpeg" alt="Dentist Image" className="image_1" />
        <div className="text-block">
          <h1>DRA. YAMILE GUZMAN</h1>
          <p>Especialista en Periodoncia e Implantología</p>
          <p>Más de 12 Años de experiencia en el área</p>
          <p>OdontoMedical, Innovación y cuidado para cada sonrisa</p>
        </div>
        <a href="servicios_odo.php" className="button">CONSULTA DE VALORACION</a>

        <div className="row">
          <div className="col-sm-6 mb-3 mb-sm-0">
            <div className="card">
              <div className="card-body">
                <img src="#" alt="Dentist Image_2" className="image_2" />
                <p className="card-text">
                  Manejamos estética y funcionalidad en tus tratamientos. En OdontoMedical encontrarás múltiples tratamientos con beneficios para tu salud dental y a precios moderados.
                </p>
                <a href="servicios_odo.php" className="btn btn-primary">Conoce los tratamientos de ortodoncia que tenemos para ti</a>
              </div>
            </div>
          </div>
          <div className="col-sm-6">
            <div className="card">
              <div className="card-body">
                <img src="" alt="Dentist Image_3" className="image" />
                <p className="card-text">
                  Tu sonrisa es nuestro compromiso. En OdontoMedical encontrarás múltiples tratamientos con beneficios para tu salud dental y a precios moderados.
                </p>
                <a href="nosotros_odo.php" className="btn btn-primary">Acerca de nosotros</a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <section className="contact-section">
        <h2>Contacto</h2>
        <div className="contact-container">
          <div className="contact-box">
            <img src="../../assets/img/whatsapp.svg" alt="WhatsApp" width="50" />
            <p>+57 320 0225854</p>
            <p>(601) 7452 155</p>
          </div>
          <div className="contact-box">
            <img src="../../assets/img/email.svg" alt="Email" width="50" />
            <p>@OdontoMedical_Clinica</p>
            <p>odontomedical@gmail.com</p>
          </div>
        </div>
        <div className="map-box">
          <iframe 
            src="https://www.google.com/maps/embed?pb=..." 
            width="400" height="300" 
            style={{border: 0}} 
            allowFullScreen="" 
            loading="lazy" 
            referrerPolicy="no-referrer-when-downgrade">
          </iframe>
        </div>
      </section>

      <footer>
        <div className="footer-container">
          <div className="footer-section">
            <h4>Servicios:</h4>
            <ul>
              <li><a href="#">Blanqueamiento dental</a></li>
              <li><a href="#">Ortodoncia</a></li>
              <li><a href="#">Rehabilitación Oral</a></li>
              <li><a href="#">Implantes dentales</a></li>
            </ul>
          </div>
          <div className="footer-section">
            <h4>Sobre OdontoMedical:</h4>
            <ul>
              <li><a href="nosotros_odo.php">Acerca de nosotros</a></li>
            </ul>
          </div>
          <div className="footer-section">
            <h4>Síguenos en nuestras redes</h4>
            <div className="social-media">
              <img src="../../assets/img/email.svg" alt="Email" width="50" />
              <img src="../../assets/img/whatsapp.svg" alt="WhatsApp" width="50" />
            </div>
            <p>Dirección: Calle 70 sur #78-25</p>
            <p>Teléfono: 7566656</p>
            <p>Correo: odontomedical@gmail.com</p>
          </div>
        </div>
      </footer>
    </div>
    </>
  );
};

export default InicioOdo;
