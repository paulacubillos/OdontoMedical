import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import "../../assets/css/serviciosOdo.css";

const ServiciosOdo = () => {
  const [servicios, setServicios] = useState([]);

  useEffect(() => {
    const fetchServicios = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/servicio'); 
        setServicios(response.data);
      } catch (error) {
        console.error('Error al cargar los servicios', error);
      }
    };

    fetchServicios();
  }, []);

  return (
    <div>
      <div className="container mt-5">
        <h1 className="text-center mb-4 text-info">Servicios Disponibles</h1>
        <div className="row row-cols-1 row-cols-md-2 g-4">
          {servicios.map((servicio) => (
            <div className="col" key={servicio.id}>
              <div className="card h-100">
                {servicio.imagen && (
                  <img src={servicio.imagen} className="card-img-top" alt={servicio.nombre} />
                )}
                <div className="card-body">
                  <h5 className="card-title">{servicio.Nombre}</h5>
                  <p className="card-text">{servicio.Descripcion}</p>
                  <p className="card-text"><strong>Precio:</strong> ${servicio.Precio}</p>
                  <Link to={`/agendar_cita_odo?servicio_id=${servicio.id}`} className="btn btn-primary">Agendar</Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <footer>
        <div className="footer-container">
          <div className="footer-section">
            <h4>Servicios:</h4>
            <ul>
              <li><Link to="#">Blanqueamiento dental</Link></li>
              <li><Link to="#">Ortodoncia</Link></li>
              <li><Link to="#">Rehabilitación Oral</Link></li>
              <li><Link to="#">Implantes dentales</Link></li>
              <li><Link to="#">Cirugía Molar</Link></li>
            </ul>
          </div>
          <div className="footer-section">
            <h4>Sobre OdontoMedical:</h4>
            <ul>
              <li><Link to="/nosotros_odo">Acerca de nosotros</Link></li>
            </ul>
          </div>
          <div className="footer-section">
            <h4>Síguenos en nuestras redes</h4>
            <div className="social-media">
              <a href="#"><img src="img/instagram.svg" alt="Instagram" /></a>
              <a href="#"><img src="img/whatsapp.svg" alt="WhatsApp" /></a>
            </div>
            <p>Dirección: Calle 70 sur #78-25</p>
            <p>Teléfono: 7566656</p>
            <p>Correo: odontomedical@gmail.com</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default ServiciosOdo;
