import React, { useState } from 'react';
import axios from 'axios';
import"../../assets/css/AgendarOdoCita.css";

const AgendarFormulario = () => {
  const [formData, setFormData] = useState({
    Numero_documento: '',
    Hora: '',
    Fecha: '',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/api/citas', formData);
      alert('Cita agendada con éxito');
      console.log('Respuesta del servidor:', response.data);
      setFormData({
        Numero_documento: '',
        Hora: '',
        Fecha: '',
      });
    } catch (error) {
      console.error('Error al agendar cita:', error.response?.data || error.message);
      alert('Error al agendar la cita. Por favor, intenta de nuevo.');
    }
  };

  return (
    <div className="form-container">
      <h2>Agendar Cita</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="Numero_documento" className="form-label">Número de Documento</label>
          <input
            type="text"
            className="form-control"
            id="Numero_documento"
            name="Numero_documento"
            placeholder="Ingrese su documento"
            value={formData.Numero_documento}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="Fecha" className="form-label">Fecha</label>
          <input
            type="date"
            className="form-control"
            id="Fecha"
            name="Fecha"
            value={formData.Fecha}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="Hora" className="form-label">Hora</label>
          <input
            type="time"
            className="form-control"
            id="Hora"
            name="Hora"
            value={formData.Hora}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary">Agendar Cita</button>
      </form>
    </div>
  );
};

export default AgendarFormulario;

