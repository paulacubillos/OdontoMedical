import Table from 'react-bootstrap/Table';

function AgendaCitas() {
  return (
    <Table striped bordered hover>
      <thead>
        <tr>
          <th>#</th>
          <th>Nombre Paciente</th>
          <th>Hora</th>
          <th>Procedimiento</th>
          <th>Consultorio</th>
          <th>Fecha</th>
          <th>acciones</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>1</td>
          <td>María González</td>
          <td>10:30 AM</td>
          <td>Ortodoncia</td>
          <td>2</td>
          <td>2024-11-20</td>
          <td>
            <button>Editar</button>
            <button>Cancelar</button>
          </td>
        </tr>
        <tr>
          <td>2</td>
          <td>Juan Pérez</td>
          <td>11:00 AM</td>
          <td>Limpieza Dental</td>
          <td>1</td>
          <td>2024-11-20</td>
          <td>
            <button>Editar</button>
            <button>Cancelar</button>
          </td>
        </tr>
        <tr>
          <td>3</td>
          <td>Ana Martínez</td>
          <td>3:00 PM</td>
          <td>Cirugía Molar</td>
          <td>1</td>
          <td>2024-11-21</td>
          <td>
            <button>Editar</button>
            <button>Cancelar</button>
          </td>
        </tr>
        <tr>
          <td>4</td>
          <td>Luis Rodríguez</td>
          <td>5:30 PM</td>
          <td>Blanqueamiento Dental</td>
          <td>1</td>
          <td>2024-11-21</td>
          <td>
            <button>Editar</button>
            <button>Cancelar</button>
          </td>
        </tr>
        <tr>
          <td>5</td>
          <td>Carolina López</td>
          <td>4:00 PM</td>
          <td>Ortodoncia</td>
          <td>2</td>
          <td>2024-11-22</td>
          <td>
            <button>Editar</button>
            <button>Cancelar</button>
           </td>
        </tr>
      </tbody>
    </Table>
  );
}

export default AgendaCitas;