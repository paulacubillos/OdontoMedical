import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';

function BarraNav() {
  return (
    <Navbar expand="lg" className="navbar">
      <Container>
        <Navbar.Brand href="#home">JEFE ORTODONCIA</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link href="agenda_citas.jsx">Agenda</Nav.Link>
            <Nav.Link href="historiales.jsx">Historiales</Nav.Link>
            <Nav.Link href="cerrar_sesion.jsx">Cerrar sesión</Nav.Link>
          </Nav>
        </Navbar.Collapse> 
      </Container>
    </Navbar>
  );
}

export default BarraNav;