import { useState } from 'react'
import './App.css'

import Bienvenido from './componentes/index.jsx';
import BarraNav from './componentes/barraNavegacion.jsx';
import AgendaCitas from './componentes/agenda_citas.jsx';
import 'bootstrap/dist/css/bootstrap.min.css';
import Register from './componentes/register.jsx';

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <BarraNav/>
    <Register/>
    <Bienvenido/>
    <AgendaCitas/>
    
    </>
  )
}

export default App
